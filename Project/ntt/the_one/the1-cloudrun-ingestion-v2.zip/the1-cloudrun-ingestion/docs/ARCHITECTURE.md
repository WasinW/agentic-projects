# The1 Cloud Run Ingestion Architecture

## Overview

This document describes the Cloud Run-based data ingestion architecture for The1 Data Platform, designed to ingest data from REST APIs and Confluent Kafka into BigQuery using the Storage Write API.

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                           The1 Cloud Run Ingestion                               │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                  │
│  ┌─────────────────┐                      ┌──────────────────────────────────┐  │
│  │   AWS VPC       │                      │         Cloud Run Service        │  │
│  │   REST API      │                      │    (the1-api-ingestion)          │  │
│  │                 │   HTTP/REST          │                                  │  │
│  │  /loyalty/v2/   │◄────────────────────►│  ┌────────────────────────────┐  │  │
│  │  - members      │                      │  │     API Poller             │  │  │
│  │  - tiers        │                      │  │  (Cloud Scheduler trigger) │  │  │
│  │  - accounts     │                      │  │                            │  │  │
│  └─────────────────┘                      │  │  - Fetch from REST API     │  │  │
│                                           │  │  - Transform (light)       │  │  │
│                                           │  │  - Batch buffer            │  │  │
│                                           │  └────────────┬───────────────┘  │  │
│                                           │               │                  │  │
│  ┌─────────────────┐                      │               │                  │  │
│  │ Confluent Cloud │                      │               │                  │  │
│  │     Kafka       │                      │               ▼                  │  │
│  │                 │   Kafka Protocol     │  ┌────────────────────────────┐  │  │
│  │  Topics:        │◄────────────────────►│  │  BigQuery Writer           │  │  │
│  │  - upgraded     │                      │  │  (Storage Write API)       │  │  │
│  │  - downgraded   │                      │  │                            │  │  │
│  └─────────────────┘                      │  │  - Buffered/Committed      │  │  │
│         │                                 │  │  - Exactly-once semantics  │  │  │
│         │                                 │  │  - Batch optimization      │  │  │
│         │                                 │  └────────────┬───────────────┘  │  │
│         │                                 └───────────────┼──────────────────┘  │
│         │                                                 │                     │
│         │              ┌──────────────────────────────────┼─────────────────┐   │
│         │              │         Cloud Run Service        │                 │   │
│         │              │    (the1-kafka-ingestion)        │                 │   │
│         │              │                                  │                 │   │
│         └─────────────►│  ┌────────────────────────────┐  │                 │   │
│                        │  │   Kafka Consumer           │  │                 │   │
│                        │  │  (Long-running container)  │  │                 │   │
│                        │  │                            │  │                 │   │
│                        │  │  - Consume from topics     │  │                 │   │
│                        │  │  - Transform (light)       │  │                 │   │
│                        │  │  - Batch buffer            │  │                 │   │
│                        │  └────────────┬───────────────┘  │                 │   │
│                        │               │                  │                 │   │
│                        │               ▼                  │                 │   │
│                        │  ┌────────────────────────────┐  │                 │   │
│                        │  │  BigQuery Writer           │  │                 │   │
│                        │  │  (Storage Write API)       │──┼─────────────────┘   │
│                        │  └────────────────────────────┘  │                     │
│                        └──────────────────────────────────┘                     │
│                                                                                  │
│                                          │                                       │
│                                          ▼                                       │
│                        ┌──────────────────────────────────┐                     │
│                        │          BigQuery                │                     │
│                        │                                  │                     │
│                        │  Dataset: the1_loyalty_raw       │                     │
│                        │                                  │                     │
│                        │  Tables:                         │                     │
│                        │  - api_members                   │                     │
│                        │  - api_tiers                     │                     │
│                        │  - api_accounts                  │                     │
│                        │  - api_tier_events               │                     │
│                        │  - kafka_members_upgraded        │                     │
│                        │  - kafka_members_downgraded      │                     │
│                        │                                  │                     │
│                        └──────────────────────────────────┘                     │
│                                          │                                       │
│                                          ▼                                       │
│                        ┌──────────────────────────────────┐                     │
│                        │        Dataform (optional)       │                     │
│                        │   Transform raw → curated        │                     │
│                        └──────────────────────────────────┘                     │
│                                                                                  │
└─────────────────────────────────────────────────────────────────────────────────┘
```

## Component Details

### 1. API Ingestion Service (`the1-api-ingestion`)

**Purpose**: Poll REST API endpoints and write to BigQuery

**Trigger**: Cloud Scheduler (configurable interval, e.g., every 5 minutes)

**Components**:
- **API Client**: Handles authentication (OAuth2) and API calls
- **Transformer**: Light transformations (flatten, rename, type casting)
- **Buffer**: Batches records before writing
- **BQ Writer**: Uses Storage Write API for efficient writes

**Endpoints to Ingest**:
| Endpoint | Description | Frequency |
|----------|-------------|-----------|
| `/loyalty/v2/tiers` | Tier definitions | Daily |
| `/loyalty/v2/members/{id}` | Member info | On-demand/Batch |
| `/loyalty/v2/members/{id}/accounts` | Account info | On-demand/Batch |
| `/loyalty/v2/members/{id}/tiers/events` | Tier events | Incremental |

### 2. Kafka Ingestion Service (`the1-kafka-ingestion`)

**Purpose**: Consume Kafka events and write to BigQuery

**Trigger**: Long-running container (always-on) or Pub/Sub bridge

**Components**:
- **Kafka Consumer**: Connects to Confluent Cloud with SASL/SSL
- **Message Handler**: Deserialize and validate messages
- **Transformer**: Light transformations
- **Buffer**: Time/size-based batching
- **BQ Writer**: Storage Write API with exactly-once semantics

**Topics**:
| Topic | Description | Volume (est.) |
|-------|-------------|---------------|
| `loyalty.members.upgraded` | Member tier upgrades | ~100-1000/day |
| `loyalty.members.downgraded` | Member tier downgrades | ~100-1000/day |

### 3. BigQuery Storage Write API

**Write Mode**: `COMMITTED` (exactly-once, immediate visibility)

**Benefits**:
- High throughput (up to 1GB/s per stream)
- Exactly-once semantics
- Lower cost than streaming inserts
- Schema enforcement at write time

**Batching Strategy**:
- Batch size: 500-1000 records or 1MB
- Flush interval: 10-30 seconds
- Auto-flush on shutdown

## Infrastructure Components

### Secret Manager
```
prod/api/authenToken          # API Client ID & Secret
prod/the1ConfluentKafka       # Kafka credentials
```

### Cloud Scheduler Jobs
```yaml
the1-api-tiers-sync:
  schedule: "0 2 * * *"  # Daily at 2 AM
  target: the1-api-ingestion
  path: /ingest/tiers

the1-api-members-incremental:
  schedule: "*/15 * * * *"  # Every 15 minutes
  target: the1-api-ingestion
  path: /ingest/members/incremental
```

### VPC Configuration
```yaml
# Cloud Run needs VPC connector to access AWS VPC Endpoint
vpc_connector: projects/PROJECT/locations/REGION/connectors/vpc-connector
egress: private-ranges-only
```

## Data Flow

### API Ingestion Flow
```
1. Cloud Scheduler triggers Cloud Run
2. Cloud Run fetches token from Secret Manager
3. Authenticate with REST API (get Bearer token)
4. Call API endpoints (paginated if needed)
5. Transform response (flatten nested JSON)
6. Buffer records (batch optimization)
7. Write to BigQuery via Storage Write API
8. Return success/failure to scheduler
```

### Kafka Ingestion Flow
```
1. Cloud Run starts (long-running)
2. Fetch Kafka credentials from Secret Manager
3. Connect to Confluent Cloud (SASL/SSL)
4. Subscribe to topics
5. Consume messages (batch of 100-500)
6. Transform messages
7. Buffer for BigQuery write
8. Commit Kafka offset after BQ write success
9. Loop back to step 5
```

## Error Handling

### Retry Strategy
```python
retry_config = {
    "max_retries": 3,
    "backoff_multiplier": 2,
    "initial_delay_seconds": 1,
    "max_delay_seconds": 60
}
```

### Dead Letter Handling
- Failed records → `dead_letter` table in BigQuery
- Alert via Cloud Monitoring
- Manual reprocessing capability

### Circuit Breaker
- Open after 5 consecutive failures
- Half-open check every 60 seconds
- Close after 3 successful requests

## Monitoring & Observability

### Metrics (Cloud Monitoring)
- `ingestion/records_processed` - Counter
- `ingestion/records_failed` - Counter
- `ingestion/latency_seconds` - Histogram
- `ingestion/batch_size` - Histogram
- `kafka/consumer_lag` - Gauge

### Logging (Cloud Logging)
```json
{
  "severity": "INFO",
  "component": "api-ingestion",
  "endpoint": "/loyalty/v2/tiers",
  "records_count": 150,
  "duration_ms": 1234,
  "status": "success"
}
```

### Alerts
- High error rate (>5% in 5 minutes)
- Kafka consumer lag > 10,000
- API authentication failures
- BigQuery write failures

## Cost Estimation

### Cloud Run
| Service | vCPU | Memory | Hours/month | Est. Cost |
|---------|------|--------|-------------|-----------|
| API Ingestion | 1 | 512MB | ~100 | ~$5 |
| Kafka Ingestion | 1 | 1GB | 720 (always-on) | ~$40 |

### BigQuery Storage Write API
- $0.025 per 200MB written
- Estimated: ~10GB/month = ~$1.25

### Total Estimated Cost: ~$50-60/month
(Well under $2/hour budget)

## Security Considerations

1. **Authentication**
   - API: OAuth2 Bearer token (short-lived)
   - Kafka: SASL/SCRAM with SSL

2. **Secrets Management**
   - All credentials in Secret Manager
   - Service account with minimal permissions

3. **Network Security**
   - VPC connector for AWS endpoint access
   - Private Google Access for BigQuery

4. **Data Security**
   - No PII logging
   - BigQuery column-level security (optional)

## Deployment Strategy

### Infrastructure as Code (Terraform)
```
terraform/
├── main.tf
├── variables.tf
├── cloud_run.tf
├── scheduler.tf
├── bigquery.tf
└── iam.tf
```

### CI/CD (Cloud Build)
```yaml
steps:
  - build docker image
  - push to Artifact Registry
  - deploy to Cloud Run
  - run health check
```

## Future Enhancements

1. **Horizontal Scaling**
   - Multiple Kafka consumer instances
   - Partition-based scaling

2. **Schema Registry**
   - Confluent Schema Registry integration
   - Automatic schema evolution

3. **Real-time Analytics**
   - BigQuery Materialized Views
   - Connected Sheets for business users

4. **Data Quality**
   - Great Expectations integration
   - Automated data profiling
