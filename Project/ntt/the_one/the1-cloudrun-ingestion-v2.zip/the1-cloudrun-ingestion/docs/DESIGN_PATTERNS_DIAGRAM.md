# Design Patterns Implementation Diagram

## 🏗️ Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        PIPELINE PATTERN (Main Flow)                         │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐   │
│  │ Kafka   │───▶│Validate │───▶│ Enrich  │───▶│Transform│───▶│  Write  │   │
│  │Consumer │    │ Stage   │    │ Stage   │    │ Stage   │    │ Stage   │   │
│  └─────────┘    └────┬────┘    └────┬────┘    └────┬────┘    └────┬────┘   │
│                      │              │              │              │         │
│                      │              │              │              │         │
│                ┌─────┴─────┐  ┌────┴────┐   ┌────┴────┐    ┌────┴────┐    │
│                │ Template  │  │  API    │   │Strategy │    │BigQuery │    │
│                │  Method   │  │ Client  │   │ Pattern │    │ Writer  │    │
│                └───────────┘  └─────────┘   └────┬────┘    └─────────┘    │
│                                                  │                         │
│                                    ┌─────────────┼─────────────┐           │
│                                    ▼             ▼             ▼           │
│                               ┌────────┐   ┌────────┐   ┌────────┐        │
│                               │Upgrade │   │Downgrade│  │Default │        │
│                               │Strategy│   │Strategy │  │Strategy│        │
│                               └────────┘   └────────┘   └────────┘        │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 1️⃣ Pipeline Pattern (Pipes & Filters)

```
                    ProcessingContext flows through each stage
                    ↓
┌──────────────────────────────────────────────────────────────────┐
│                          PIPELINE                                 │
│                                                                   │
│   KafkaMessage                                                    │
│        │                                                          │
│        ▼                                                          │
│   ┌─────────┐     ┌─────────┐     ┌─────────┐     ┌─────────┐    │
│   │ Stage 1 │────▶│ Stage 2 │────▶│ Stage 3 │────▶│ Stage 4 │    │
│   │Validate │     │ Enrich  │     │Transform│     │  Write  │    │
│   └─────────┘     └─────────┘     └─────────┘     └─────────┘    │
│                                                          │        │
│                                                          ▼        │
│                                               ProcessingResult    │
└──────────────────────────────────────────────────────────────────┘

Key Benefits:
✅ Single Responsibility - each stage does one thing
✅ Easy to add/remove/reorder stages
✅ Easy to test individual stages
✅ Clear data flow
```

---

## 2️⃣ Template Method Pattern (BaseStage)

```
┌──────────────────────────────────────────────────────┐
│                   BaseStage (Abstract)                │
├──────────────────────────────────────────────────────┤
│                                                       │
│  async process(context):        ◀─── Template Method │
│      if should_skip(context):                        │
│          return context                              │
│      try:                                            │
│          context = await _execute(context)  ◀─ Hook  │
│          log success                                 │
│      except:                                         │
│          mark failed                                 │
│      return context                                  │
│                                                       │
│  @abstractmethod                                     │
│  async _execute(context)        ◀─── Subclass impl  │
│                                                       │
└──────────────────────────────────────────────────────┘
                        │
        ┌───────────────┼───────────────┐
        ▼               ▼               ▼
┌──────────────┐ ┌──────────────┐ ┌──────────────┐
│ValidationStage│ │EnrichmentStage│ │TransformStage│
├──────────────┤ ├──────────────┤ ├──────────────┤
│_execute():    │ │_execute():    │ │_execute():   │
│ check fields  │ │ call API      │ │ apply        │
│ validate      │ │ store data    │ │ strategy     │
└──────────────┘ └──────────────┘ └──────────────┘

Key Benefits:
✅ Common logic in base class (DRY)
✅ Consistent error handling
✅ Consistent logging
✅ Subclasses focus on specific logic
```

---

## 3️⃣ Strategy Pattern (Transformations)

```
┌────────────────────────────────────────────────────────────┐
│                   TransformationStage                       │
├────────────────────────────────────────────────────────────┤
│                                                             │
│  strategies: dict[topic, TransformStrategy]                 │
│                                                             │
│  _execute(context):                                         │
│      strategy = strategies.get(context.topic)               │
│      transformed = strategy.transform(message, enriched)    │
│                                                             │
└────────────────────────────────────────────────────────────┘
                           │
                           │ selects based on topic
                           ▼
        ┌──────────────────────────────────────────┐
        │          TransformStrategy (ABC)          │
        │  + transform(message, enriched) -> dict   │
        └──────────────────────────────────────────┘
                           │
         ┌─────────────────┼─────────────────┐
         ▼                 ▼                 ▼
┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐
│UpgradeStrategy  │ │DowngradeStrategy│ │PassthroughStrat │
├─────────────────┤ ├─────────────────┤ ├─────────────────┤
│transform():     │ │transform():     │ │transform():     │
│ event_type:     │ │ event_type:     │ │ pass through    │
│   "upgrade"     │ │   "downgrade"   │ │ with metadata   │
│ + enriched      │ │ + enriched      │ │                 │
│   fields        │ │   fields        │ │                 │
└─────────────────┘ └─────────────────┘ └─────────────────┘

Key Benefits:
✅ Easy to add new topic handlers
✅ Transformation logic is isolated
✅ Runtime strategy selection
✅ Open for extension, closed for modification
```

---

## 4️⃣ Builder Pattern (Pipeline Construction)

```
┌──────────────────────────────────────────────────────────────┐
│                      PipelineBuilder                          │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│  pipeline = (                                                 │
│      PipelineBuilder()                                        │
│      .with_api_client(api_client)      # Set dependencies    │
│      .with_writer_pool(writer_pool)    # Set dependencies    │
│      .with_topic_mapping(mapping)      # Configuration       │
│      .with_validation(["member_id"])   # Add stage           │
│      .with_enrichment()                # Add stage           │
│      .with_transformation()            # Add stage           │
│      .with_bigquery_write()            # Add stage           │
│      .build()                          # Create Pipeline     │
│  )                                                            │
│                                                               │
└──────────────────────────────────────────────────────────────┘

Key Benefits:
✅ Fluent API - readable configuration
✅ Separates construction from representation
✅ Easy to create different pipeline variants
✅ Validates dependencies before building
```

---

## 5️⃣ Data Flow with ProcessingContext

```
┌──────────────────────────────────────────────────────────────────┐
│                      ProcessingContext                            │
├──────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌─ raw_message: KafkaMessage ─────────────────────────────────┐  │
│  │  topic: "loyalty.members.upgraded"                          │  │
│  │  value: { member_id: "123", previous_tier: "silver", ... }  │  │
│  └─────────────────────────────────────────────────────────────┘  │
│                              │                                    │
│                              ▼ After Enrichment Stage             │
│  ┌─ enriched_data ─────────────────────────────────────────────┐  │
│  │  member_info: { first_name: "John", status: "active" }      │  │
│  │  accounts: [ { account_id: "A1", balance: 5000 } ]          │  │
│  └─────────────────────────────────────────────────────────────┘  │
│                              │                                    │
│                              ▼ After Transform Stage              │
│  ┌─ transformed_data ──────────────────────────────────────────┐  │
│  │  event_type: "upgrade"                                      │  │
│  │  member_id: "123"                                           │  │
│  │  member_name: "John"    ◀── from enriched                   │  │
│  │  _processed_at: "2024-..."                                  │  │
│  └─────────────────────────────────────────────────────────────┘  │
│                                                                   │
│  status: SUCCESS | FAILED | SKIPPED                               │
│  errors: []                                                       │
│                                                                   │
└──────────────────────────────────────────────────────────────────┘
```

---

## 📊 Pattern Summary

| Pattern | Where Used | Purpose |
|---------|------------|---------|
| **Pipeline** | Main architecture | Sequential processing |
| **Template Method** | BaseStage | Common processing skeleton |
| **Strategy** | TransformationStage | Topic-specific transforms |
| **Builder** | PipelineBuilder | Fluent pipeline construction |
| **Protocol** | PipelineStage | Interface definition |

---

## 🔄 Alternative: Chain of Responsibility (If Needed Later)

```
Use Chain of Responsibility when:
- Need to skip stages based on conditions
- Handler can decide not to pass to next
- Dynamic handler chains

Example:
- If member not found → skip enrichment → go to transform
- If transformation fails → go to dead letter → stop chain
```

---

## ❌ Patterns NOT Used (and Why)

| Pattern | Reason Not Used |
|---------|-----------------|
| **Factory** | Only 2 topics - overkill |
| **Observer** | No event broadcasting needed |
| **Singleton** | Prefer dependency injection |
| **Decorator** | Pipeline stages sufficient |
