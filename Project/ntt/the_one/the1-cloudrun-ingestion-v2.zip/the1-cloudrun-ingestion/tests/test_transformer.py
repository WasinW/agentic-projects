"""Tests for transformer utilities."""

import pytest
from datetime import datetime, timezone


class TestFlattenDict:
    """Tests for flatten_dict function."""

    def test_simple_dict(self):
        """Test flattening simple dict."""
        from common.transformer import flatten_dict
        
        data = {"a": 1, "b": 2}
        result = flatten_dict(data)
        
        assert result == {"a": 1, "b": 2}

    def test_nested_dict(self):
        """Test flattening nested dict."""
        from common.transformer import flatten_dict
        
        data = {"a": {"b": 1, "c": 2}}
        result = flatten_dict(data)
        
        assert result == {"a_b": 1, "a_c": 2}

    def test_deeply_nested(self):
        """Test flattening deeply nested dict."""
        from common.transformer import flatten_dict
        
        data = {"a": {"b": {"c": 1}}}
        result = flatten_dict(data)
        
        assert result == {"a_b_c": 1}

    def test_with_list(self):
        """Test flattening dict with list values."""
        from common.transformer import flatten_dict
        
        data = {"a": [1, 2, 3]}
        result = flatten_dict(data)
        
        assert result["a"] == "[1, 2, 3]"  # JSON string

    def test_custom_separator(self):
        """Test flattening with custom separator."""
        from common.transformer import flatten_dict
        
        data = {"a": {"b": 1}}
        result = flatten_dict(data, separator=".")
        
        assert result == {"a.b": 1}


class TestSnakeCase:
    """Tests for snake_case function."""

    def test_camel_case(self):
        """Test converting camelCase."""
        from common.transformer import snake_case
        
        assert snake_case("camelCase") == "camel_case"

    def test_pascal_case(self):
        """Test converting PascalCase."""
        from common.transformer import snake_case
        
        assert snake_case("PascalCase") == "pascal_case"

    def test_already_snake_case(self):
        """Test already snake_case string."""
        from common.transformer import snake_case
        
        assert snake_case("already_snake") == "already_snake"

    def test_all_caps(self):
        """Test all caps string."""
        from common.transformer import snake_case
        
        assert snake_case("HTTP") == "http"


class TestConvertKeysToSnakeCase:
    """Tests for convert_keys_to_snake_case function."""

    def test_simple_dict(self):
        """Test converting simple dict keys."""
        from common.transformer import convert_keys_to_snake_case
        
        data = {"firstName": "John", "lastName": "Doe"}
        result = convert_keys_to_snake_case(data)
        
        assert result == {"first_name": "John", "last_name": "Doe"}

    def test_nested_dict(self):
        """Test converting nested dict keys."""
        from common.transformer import convert_keys_to_snake_case
        
        data = {"userData": {"firstName": "John"}}
        result = convert_keys_to_snake_case(data)
        
        assert result == {"user_data": {"first_name": "John"}}

    def test_with_list(self):
        """Test converting dict with list of dicts."""
        from common.transformer import convert_keys_to_snake_case
        
        data = {"userList": [{"firstName": "John"}, {"firstName": "Jane"}]}
        result = convert_keys_to_snake_case(data)
        
        assert result["user_list"][0]["first_name"] == "John"


class TestAddMetadata:
    """Tests for add_metadata function."""

    def test_adds_metadata_fields(self):
        """Test that metadata fields are added."""
        from common.transformer import add_metadata
        
        record = {"id": 1}
        result = add_metadata(record, "test_source")
        
        assert result["id"] == 1
        assert result["_source"] == "test_source"
        assert "_ingested_at" in result

    def test_with_source_timestamp(self):
        """Test with source timestamp."""
        from common.transformer import add_metadata
        
        source_ts = datetime(2024, 1, 1, tzinfo=timezone.utc)
        record = {"id": 1}
        result = add_metadata(record, "test", source_ts)
        
        assert result["_source_timestamp"] == source_ts.isoformat()


class TestSafeGet:
    """Tests for safe_get function."""

    def test_simple_get(self):
        """Test simple key access."""
        from common.transformer import safe_get
        
        data = {"a": 1}
        assert safe_get(data, "a") == 1

    def test_nested_get(self):
        """Test nested key access."""
        from common.transformer import safe_get
        
        data = {"a": {"b": {"c": 1}}}
        assert safe_get(data, "a", "b", "c") == 1

    def test_missing_key(self):
        """Test missing key returns default."""
        from common.transformer import safe_get
        
        data = {"a": 1}
        assert safe_get(data, "b", default=0) == 0

    def test_missing_nested_key(self):
        """Test missing nested key returns default."""
        from common.transformer import safe_get
        
        data = {"a": {"b": 1}}
        assert safe_get(data, "a", "c", default="N/A") == "N/A"


class TestRecordTransformer:
    """Tests for RecordTransformer class."""

    def test_basic_transform(self):
        """Test basic transformation."""
        from common.transformer import RecordTransformer
        
        transformer = RecordTransformer(source="test")
        record = {"id": 1, "name": "test"}
        result = transformer.transform(record)
        
        assert result["id"] == 1
        assert result["_source"] == "test"

    def test_flatten_option(self):
        """Test flatten option."""
        from common.transformer import RecordTransformer
        
        transformer = RecordTransformer(flatten=True, source="test")
        record = {"user": {"name": "John"}}
        result = transformer.transform(record)
        
        assert "user_name" in result

    def test_snake_case_option(self):
        """Test snake case conversion."""
        from common.transformer import RecordTransformer
        
        transformer = RecordTransformer(snake_case_keys=True, source="test")
        record = {"firstName": "John"}
        result = transformer.transform(record)
        
        assert "first_name" in result

    def test_field_mapping(self):
        """Test field name mapping."""
        from common.transformer import RecordTransformer
        
        transformer = RecordTransformer(
            field_mapping={"old_name": "new_name"},
            snake_case_keys=False,
            source="test"
        )
        record = {"old_name": "value"}
        result = transformer.transform(record)
        
        assert "new_name" in result
        assert "old_name" not in result

    def test_include_fields(self):
        """Test field inclusion filter."""
        from common.transformer import RecordTransformer
        
        transformer = RecordTransformer(
            include_fields=["id", "name"],
            snake_case_keys=False,
            source="test"
        )
        record = {"id": 1, "name": "test", "extra": "value"}
        result = transformer.transform(record)
        
        assert "id" in result
        assert "name" in result
        assert "extra" not in result

    def test_exclude_fields(self):
        """Test field exclusion filter."""
        from common.transformer import RecordTransformer
        
        transformer = RecordTransformer(
            exclude_fields=["secret"],
            snake_case_keys=False,
            source="test"
        )
        record = {"id": 1, "secret": "password"}
        result = transformer.transform(record)
        
        assert "id" in result
        assert "secret" not in result

    def test_transform_batch(self):
        """Test batch transformation."""
        from common.transformer import RecordTransformer
        
        transformer = RecordTransformer(source="test")
        records = [{"id": 1}, {"id": 2}, {"id": 3}]
        results = transformer.transform_batch(records)
        
        assert len(results) == 3
        assert all("_source" in r for r in results)
