"""Tests for API client."""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from datetime import datetime, timezone

import httpx


# Test fixtures
@pytest.fixture
def mock_settings():
    """Mock settings."""
    with patch("api_ingestion.client.get_settings") as mock:
        settings = MagicMock()
        settings.api_base_url = "https://api.example.com"
        settings.api_gateway_id = "test-gateway"
        settings.api_timeout_seconds = 30
        settings.api_secret_name = "test-secret"
        mock.return_value = settings
        yield settings


@pytest.fixture
def mock_credentials():
    """Mock API credentials."""
    with patch("api_ingestion.client.get_api_credentials") as mock:
        mock.return_value = {
            "clientId": "test-client",
            "clientSecret": "test-secret",
        }
        yield mock


@pytest.fixture
def api_client(mock_settings, mock_credentials):
    """Create API client with mocks."""
    from api_ingestion.client import LoyaltyAPIClient
    return LoyaltyAPIClient()


class TestLoyaltyAPIClient:
    """Tests for LoyaltyAPIClient."""

    @pytest.mark.asyncio
    async def test_authenticate_success(self, api_client):
        """Test successful authentication."""
        mock_response = {
            "access_token": "test-token-123",
            "expires_in": 3600,
        }
        
        with patch.object(
            api_client._client, 
            "post", 
            new_callable=AsyncMock
        ) as mock_post:
            mock_post.return_value = MagicMock(
                status_code=200,
                json=lambda: mock_response
            )
            
            token = await api_client._authenticate()
            
            assert token == "test-token-123"
            assert api_client._access_token == "test-token-123"
            mock_post.assert_called_once()

    @pytest.mark.asyncio
    async def test_authenticate_failure(self, api_client):
        """Test authentication failure."""
        from api_ingestion.client import AuthenticationError
        
        with patch.object(
            api_client._client,
            "post",
            new_callable=AsyncMock
        ) as mock_post:
            mock_post.return_value = MagicMock(
                status_code=401,
                text="Unauthorized"
            )
            
            with pytest.raises(AuthenticationError):
                await api_client._authenticate()

    @pytest.mark.asyncio
    async def test_get_tiers(self, api_client):
        """Test get tiers endpoint."""
        mock_tiers = [
            {"tier_id": "1", "tier_name": "Bronze"},
            {"tier_id": "2", "tier_name": "Silver"},
        ]
        
        # Mock authentication
        api_client._access_token = "test-token"
        api_client._token_expires_at = datetime.now(timezone.utc).replace(
            year=2030
        )
        
        with patch.object(
            api_client._client,
            "request",
            new_callable=AsyncMock
        ) as mock_request:
            mock_request.return_value = MagicMock(
                status_code=200,
                json=lambda: {"data": mock_tiers}
            )
            
            tiers = await api_client.get_tiers()
            
            assert len(tiers) == 2
            assert tiers[0]["tier_id"] == "1"

    @pytest.mark.asyncio
    async def test_get_member(self, api_client):
        """Test get member endpoint."""
        mock_member = {
            "member_id": "123",
            "first_name": "John",
            "tier_id": "2",
        }
        
        api_client._access_token = "test-token"
        api_client._token_expires_at = datetime.now(timezone.utc).replace(
            year=2030
        )
        
        with patch.object(
            api_client._client,
            "request",
            new_callable=AsyncMock
        ) as mock_request:
            mock_request.return_value = MagicMock(
                status_code=200,
                json=lambda: {"data": mock_member}
            )
            
            member = await api_client.get_member("123")
            
            assert member["member_id"] == "123"
            assert member["first_name"] == "John"

    @pytest.mark.asyncio
    async def test_rate_limit_handling(self, api_client):
        """Test rate limit error handling."""
        from api_ingestion.client import RateLimitError
        
        api_client._access_token = "test-token"
        api_client._token_expires_at = datetime.now(timezone.utc).replace(
            year=2030
        )
        
        with patch.object(
            api_client._client,
            "request",
            new_callable=AsyncMock
        ) as mock_request:
            mock_request.return_value = MagicMock(
                status_code=429,
                headers={"Retry-After": "60"}
            )
            
            with pytest.raises(RateLimitError):
                await api_client._request("GET", "/test")

    def test_token_validity_check(self, api_client):
        """Test token validity checking."""
        # No token
        assert not api_client._is_token_valid()
        
        # Expired token
        api_client._access_token = "test"
        api_client._token_expires_at = datetime(2020, 1, 1, tzinfo=timezone.utc)
        assert not api_client._is_token_valid()
        
        # Valid token
        api_client._token_expires_at = datetime(2030, 1, 1, tzinfo=timezone.utc)
        assert api_client._is_token_valid()

    def test_get_stats(self, api_client):
        """Test statistics retrieval."""
        api_client._request_count = 10
        api_client._error_count = 2
        
        stats = api_client.get_stats()
        
        assert stats["request_count"] == 10
        assert stats["error_count"] == 2
