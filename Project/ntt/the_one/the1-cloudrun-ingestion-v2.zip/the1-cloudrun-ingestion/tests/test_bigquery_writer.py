"""Tests for BigQuery writer."""

import pytest
from unittest.mock import MagicMock, patch
import threading
import time


@pytest.fixture
def mock_settings():
    """Mock settings."""
    with patch("common.bigquery_writer.get_settings") as mock:
        settings = MagicMock()
        settings.gcp_project = "test-project"
        settings.bq_dataset = "test_dataset"
        settings.bq_batch_size = 10
        settings.bq_flush_interval_seconds = 5
        settings.bq_max_batch_bytes = 1000000
        mock.return_value = settings
        yield settings


@pytest.fixture
def mock_bq_client():
    """Mock BigQuery client."""
    with patch("common.bigquery_writer.bigquery.Client") as mock:
        client = MagicMock()
        client.insert_rows_json.return_value = []  # No errors
        mock.return_value = client
        yield client


@pytest.fixture
def mock_write_client():
    """Mock BigQuery Storage Write client."""
    with patch("common.bigquery_writer.BigQueryWriteClient") as mock:
        yield mock.return_value


@pytest.fixture
def writer(mock_settings, mock_bq_client, mock_write_client):
    """Create BigQuery writer with mocks."""
    from common.bigquery_writer import BigQueryWriter
    
    return BigQueryWriter(
        project_id="test-project",
        dataset_id="test_dataset",
        table_id="test_table",
        batch_size=5,
        flush_interval_seconds=2,
    )


class TestBigQueryWriter:
    """Tests for BigQueryWriter."""

    def test_init(self, writer):
        """Test writer initialization."""
        assert writer.project_id == "test-project"
        assert writer.dataset_id == "test_dataset"
        assert writer.table_id == "test_table"
        assert writer.batch_size == 5

    def test_table_ref(self, writer):
        """Test table reference property."""
        assert writer.table_ref == "test-project.test_dataset.test_table"

    def test_add_record(self, writer):
        """Test adding a single record."""
        record = {"id": 1, "name": "test"}
        writer.add(record)
        
        assert len(writer._buffer) == 1
        assert writer._buffer[0]["id"] == 1
        assert "_ingested_at" in writer._buffer[0]

    def test_add_batch(self, writer):
        """Test adding multiple records."""
        records = [
            {"id": 1, "name": "test1"},
            {"id": 2, "name": "test2"},
            {"id": 3, "name": "test3"},
        ]
        writer.add_batch(records)
        
        assert len(writer._buffer) == 3

    def test_auto_flush_on_batch_size(self, writer, mock_bq_client):
        """Test auto-flush when batch size is reached."""
        # Add records up to batch size
        for i in range(5):
            writer.add({"id": i})
        
        # Should have flushed
        assert len(writer._buffer) == 0
        assert writer._total_rows_written == 5
        mock_bq_client.insert_rows_json.assert_called_once()

    def test_flush_empty_buffer(self, writer):
        """Test flush with empty buffer."""
        result = writer.flush()
        
        assert result.success is True
        assert result.rows_written == 0

    def test_flush_with_records(self, writer, mock_bq_client):
        """Test flush with records in buffer."""
        writer.add({"id": 1})
        writer.add({"id": 2})
        
        result = writer.flush()
        
        assert result.success is True
        assert result.rows_written == 2
        assert len(writer._buffer) == 0

    def test_flush_with_errors(self, writer, mock_bq_client):
        """Test flush when BigQuery returns errors."""
        mock_bq_client.insert_rows_json.return_value = [
            {"errors": ["test error"]}
        ]
        
        writer.add({"id": 1})
        result = writer.flush()
        
        assert result.success is False
        assert len(result.errors) > 0

    def test_get_stats(self, writer):
        """Test statistics retrieval."""
        writer.add({"id": 1})
        
        stats = writer.get_stats()
        
        assert stats["table"] == "test-project.test_dataset.test_table"
        assert stats["buffer_size"] == 1
        assert "total_rows_written" in stats

    def test_context_manager(self, mock_settings, mock_bq_client, mock_write_client):
        """Test context manager usage."""
        from common.bigquery_writer import BigQueryWriter
        
        with BigQueryWriter(
            project_id="test-project",
            dataset_id="test_dataset",
            table_id="test_table",
        ) as writer:
            writer.add({"id": 1})
        
        # Should have flushed on exit
        mock_bq_client.insert_rows_json.assert_called()


class TestBigQueryWriterPool:
    """Tests for BigQueryWriterPool."""

    def test_get_writer(self, mock_settings, mock_bq_client, mock_write_client):
        """Test getting a writer from pool."""
        from common.bigquery_writer import BigQueryWriterPool
        
        pool = BigQueryWriterPool(
            project_id="test-project",
            dataset_id="test_dataset"
        )
        
        writer1 = pool.get_writer("table1")
        writer2 = pool.get_writer("table1")
        writer3 = pool.get_writer("table2")
        
        # Same table should return same writer
        assert writer1 is writer2
        # Different table should return different writer
        assert writer1 is not writer3
        
        pool.close_all()

    def test_flush_all(self, mock_settings, mock_bq_client, mock_write_client):
        """Test flushing all writers."""
        from common.bigquery_writer import BigQueryWriterPool
        
        pool = BigQueryWriterPool(
            project_id="test-project",
            dataset_id="test_dataset"
        )
        
        pool.get_writer("table1").add({"id": 1})
        pool.get_writer("table2").add({"id": 2})
        
        results = pool.flush_all()
        
        assert "table1" in results
        assert "table2" in results
        
        pool.close_all()

    def test_get_all_stats(self, mock_settings, mock_bq_client, mock_write_client):
        """Test getting stats for all writers."""
        from common.bigquery_writer import BigQueryWriterPool
        
        pool = BigQueryWriterPool(
            project_id="test-project",
            dataset_id="test_dataset"
        )
        
        pool.get_writer("table1")
        pool.get_writer("table2")
        
        stats = pool.get_all_stats()
        
        assert "table1" in stats
        assert "table2" in stats
        
        pool.close_all()
