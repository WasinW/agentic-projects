"""Test configuration and fixtures."""

import pytest
import sys
from pathlib import Path

# Add src to path for imports
src_path = Path(__file__).parent.parent / "src"
sys.path.insert(0, str(src_path))


@pytest.fixture(autouse=True)
def reset_singletons():
    """Reset singleton instances between tests."""
    # Clear any cached settings
    from common.config import get_settings
    get_settings.cache_clear()
    
    yield
    
    # Cleanup after test
    get_settings.cache_clear()


@pytest.fixture
def sample_member_data():
    """Sample member data for testing."""
    return {
        "memberId": "123-456",
        "firstName": "John",
        "lastName": "Doe",
        "email": "john@example.com",
        "tierId": "gold",
        "totalPoints": 5000,
        "status": "active",
    }


@pytest.fixture
def sample_tier_data():
    """Sample tier data for testing."""
    return {
        "tierId": "gold",
        "tierName": "Gold",
        "tierLevel": 2,
        "minPoints": 1000,
        "maxPoints": 5000,
        "benefits": ["free_shipping", "bonus_points"],
    }


@pytest.fixture
def sample_kafka_message():
    """Sample Kafka message for testing."""
    return {
        "member_id": "123-456",
        "previous_tier_id": "silver",
        "new_tier_id": "gold",
        "upgraded_at": "2024-01-15T10:30:00Z",
        "reason": "points_threshold",
        "points_at_upgrade": 5000,
    }
