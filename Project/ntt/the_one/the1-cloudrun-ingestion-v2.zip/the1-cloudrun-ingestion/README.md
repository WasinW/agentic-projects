# The1 Cloud Run Ingestion

Cloud Run-based data ingestion for The1 Data Platform.

## Features

- **API Ingestion**: Poll REST API endpoints and write to BigQuery
- **Kafka Ingestion**: Consume from Confluent Cloud and write to BigQuery
- **BigQuery Storage Write API**: High-throughput, exactly-once writes
- **Config-driven**: YAML-based configuration

## Project Structure

```
the1-cloudrun-ingestion/
├── docs/
│   └── ARCHITECTURE.md
├── src/
│   ├── common/
│   │   ├── __init__.py
│   │   ├── config.py           # Configuration management
│   │   ├── secrets.py          # Secret Manager client
│   │   ├── bigquery_writer.py  # BQ Storage Write API wrapper
│   │   ├── transformer.py      # Data transformation utils
│   │   └── logging_config.py   # Structured logging
│   ├── api_ingestion/
│   │   ├── __init__.py
│   │   ├── main.py             # FastAPI application
│   │   ├── client.py           # REST API client
│   │   ├── handlers.py         # Endpoint handlers
│   │   └── schemas.py          # Pydantic models
│   ├── kafka_ingestion/
│   │   ├── __init__.py
│   │   ├── main.py             # Kafka consumer entry
│   │   ├── consumer.py         # Kafka consumer wrapper
│   │   ├── handlers.py         # Message handlers
│   │   └── schemas.py          # Pydantic models
│   └── configs/
│       ├── api_endpoints.yaml
│       ├── kafka_topics.yaml
│       └── bigquery_schemas.yaml
├── terraform/
│   ├── main.tf
│   ├── variables.tf
│   ├── cloud_run.tf
│   ├── scheduler.tf
│   └── bigquery.tf
├── tests/
│   ├── test_api_client.py
│   ├── test_kafka_consumer.py
│   └── test_bigquery_writer.py
├── Dockerfile.api
├── Dockerfile.kafka
├── docker-compose.yaml
├── requirements.txt
├── pyproject.toml
└── README.md
```

## Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Set Environment Variables

```bash
export GCP_PROJECT=your-project-id
export GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json
```

### 3. Run Locally

**API Ingestion:**
```bash
cd src/api_ingestion
uvicorn main:app --reload --port 8080
```

**Kafka Ingestion:**
```bash
cd src/kafka_ingestion
python main.py
```

### 4. Deploy to Cloud Run

```bash
# Build and push
gcloud builds submit --tag gcr.io/$PROJECT_ID/the1-api-ingestion -f Dockerfile.api
gcloud builds submit --tag gcr.io/$PROJECT_ID/the1-kafka-ingestion -f Dockerfile.kafka

# Deploy
gcloud run deploy the1-api-ingestion \
  --image gcr.io/$PROJECT_ID/the1-api-ingestion \
  --region asia-southeast1 \
  --service-account ingestion-sa@$PROJECT_ID.iam.gserviceaccount.com

gcloud run deploy the1-kafka-ingestion \
  --image gcr.io/$PROJECT_ID/the1-kafka-ingestion \
  --region asia-southeast1 \
  --no-cpu-throttling \
  --min-instances 1 \
  --service-account ingestion-sa@$PROJECT_ID.iam.gserviceaccount.com
```

## Configuration

See `src/configs/` for YAML configuration files.

## License

Internal use only - The1 (Central Group)
