"""API ingestion handlers - business logic for each endpoint."""

import asyncio
from datetime import datetime, timezone
from typing import Any

import structlog

from common import BigQueryWriterPool, RecordTransformer
from .client import LoyaltyAPIClient

logger = structlog.get_logger(__name__)


# Table names
TABLE_TIERS = "api_tiers"
TABLE_MEMBERS = "api_members"
TABLE_ACCOUNTS = "api_accounts"
TABLE_TIER_EVENTS = "api_tier_events"


def get_transformer(source: str) -> RecordTransformer:
    """Get transformer for a source.
    
    Args:
        source: Source identifier
        
    Returns:
        Configured transformer
    """
    return RecordTransformer(
        flatten=True,
        snake_case_keys=True,
        source=source,
    )


async def ingest_tiers(
    client: LoyaltyAPIClient,
    writer_pool: BigQueryWriterPool,
) -> dict[str, Any]:
    """Ingest tier definitions.
    
    Args:
        client: API client
        writer_pool: BigQuery writer pool
        
    Returns:
        Result dict with records_processed count
    """
    logger.info("ingest_tiers_start")
    
    transformer = get_transformer("api_tiers")
    writer = writer_pool.get_writer(TABLE_TIERS)
    
    # Fetch tiers
    tiers = await client.get_tiers()
    
    if not tiers:
        logger.warning("no_tiers_returned")
        return {"records_processed": 0}
    
    # Transform and write
    for tier in tiers:
        transformed = transformer.transform(tier)
        writer.add(transformed)
    
    # Flush to ensure data is written
    result = writer.flush()
    
    logger.info(
        "ingest_tiers_completed",
        records_processed=len(tiers),
        write_success=result.success,
    )
    
    return {"records_processed": len(tiers)}


async def ingest_member(
    client: LoyaltyAPIClient,
    writer_pool: BigQueryWriterPool,
    member_id: str,
) -> dict[str, Any]:
    """Ingest single member.
    
    Args:
        client: API client
        writer_pool: BigQuery writer pool
        member_id: Member ID
        
    Returns:
        Result dict with records_processed count
    """
    logger.info("ingest_member_start", member_id=member_id)
    
    transformer = get_transformer("api_members")
    writer = writer_pool.get_writer(TABLE_MEMBERS)
    
    # Fetch member
    member = await client.get_member(member_id)
    
    # Add member_id if not present
    member["member_id"] = member_id
    
    # Transform and write
    transformed = transformer.transform(member)
    writer.add(transformed)
    writer.flush()
    
    logger.info("ingest_member_completed", member_id=member_id)
    
    return {"records_processed": 1}


async def ingest_member_accounts(
    client: LoyaltyAPIClient,
    writer_pool: BigQueryWriterPool,
    member_id: str,
) -> dict[str, Any]:
    """Ingest member accounts.
    
    Args:
        client: API client
        writer_pool: BigQuery writer pool
        member_id: Member ID
        
    Returns:
        Result dict with records_processed count
    """
    logger.info("ingest_member_accounts_start", member_id=member_id)
    
    transformer = get_transformer("api_accounts")
    writer = writer_pool.get_writer(TABLE_ACCOUNTS)
    
    # Fetch accounts
    accounts = await client.get_member_accounts(member_id)
    
    if not accounts:
        logger.info("no_accounts_found", member_id=member_id)
        return {"records_processed": 0}
    
    # Transform and write
    for account in accounts:
        account["member_id"] = member_id
        transformed = transformer.transform(account)
        writer.add(transformed)
    
    writer.flush()
    
    logger.info(
        "ingest_member_accounts_completed",
        member_id=member_id,
        records_processed=len(accounts),
    )
    
    return {"records_processed": len(accounts)}


async def ingest_member_tier_events(
    client: LoyaltyAPIClient,
    writer_pool: BigQueryWriterPool,
    member_id: str,
) -> dict[str, Any]:
    """Ingest member tier events.
    
    Args:
        client: API client
        writer_pool: BigQuery writer pool
        member_id: Member ID
        
    Returns:
        Result dict with records_processed count
    """
    logger.info("ingest_member_tier_events_start", member_id=member_id)
    
    transformer = get_transformer("api_tier_events")
    writer = writer_pool.get_writer(TABLE_TIER_EVENTS)
    
    # Fetch tier events
    events = await client.get_member_tier_events(member_id)
    
    if not events:
        logger.info("no_tier_events_found", member_id=member_id)
        return {"records_processed": 0}
    
    # Transform and write
    for event in events:
        event["member_id"] = member_id
        transformed = transformer.transform(event)
        writer.add(transformed)
    
    writer.flush()
    
    logger.info(
        "ingest_member_tier_events_completed",
        member_id=member_id,
        records_processed=len(events),
    )
    
    return {"records_processed": len(events)}


async def ingest_members_batch(
    client: LoyaltyAPIClient,
    writer_pool: BigQueryWriterPool,
    member_ids: list[str],
    include_accounts: bool = True,
    include_tier_events: bool = True,
    concurrency: int = 5,
) -> dict[str, Any]:
    """Ingest multiple members with their related data.
    
    Args:
        client: API client
        writer_pool: BigQuery writer pool
        member_ids: List of member IDs
        include_accounts: Whether to include accounts
        include_tier_events: Whether to include tier events
        concurrency: Max concurrent API calls
        
    Returns:
        Result dict with records_processed count
    """
    logger.info(
        "ingest_members_batch_start",
        member_count=len(member_ids),
        include_accounts=include_accounts,
        include_tier_events=include_tier_events,
    )
    
    total_records = 0
    semaphore = asyncio.Semaphore(concurrency)
    
    async def process_member(member_id: str) -> int:
        """Process single member with concurrency control."""
        async with semaphore:
            records = 0
            
            try:
                # Member info
                result = await ingest_member(client, writer_pool, member_id)
                records += result["records_processed"]
                
                # Accounts
                if include_accounts:
                    result = await ingest_member_accounts(client, writer_pool, member_id)
                    records += result["records_processed"]
                
                # Tier events
                if include_tier_events:
                    result = await ingest_member_tier_events(client, writer_pool, member_id)
                    records += result["records_processed"]
                
                return records
                
            except Exception as e:
                logger.error(
                    "member_processing_failed",
                    member_id=member_id,
                    error=str(e),
                )
                return 0
    
    # Process all members concurrently
    tasks = [process_member(member_id) for member_id in member_ids]
    results = await asyncio.gather(*tasks)
    
    total_records = sum(results)
    
    # Final flush
    writer_pool.flush_all()
    
    logger.info(
        "ingest_members_batch_completed",
        member_count=len(member_ids),
        total_records=total_records,
    )
    
    return {"records_processed": total_records}
