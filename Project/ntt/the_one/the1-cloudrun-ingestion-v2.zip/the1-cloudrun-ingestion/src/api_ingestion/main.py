"""API Ingestion Service - FastAPI Application.

This service polls REST API endpoints and writes data to BigQuery.
Triggered by Cloud Scheduler for periodic ingestion.
"""

import asyncio
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import Any

from fastapi import FastAPI, HTTPException, BackgroundTasks, Query
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import structlog

from common import (
    setup_logging,
    get_logger,
    get_settings,
    BigQueryWriterPool,
)
from .client import LoyaltyAPIClient
from .handlers import (
    ingest_tiers,
    ingest_member,
    ingest_member_accounts,
    ingest_member_tier_events,
    ingest_members_batch,
)

# Setup logging
setup_logging("the1-api-ingestion")
logger = get_logger(__name__)

# Global resources
writer_pool: BigQueryWriterPool | None = None
api_client: LoyaltyAPIClient | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler."""
    global writer_pool, api_client
    
    logger.info("application_starting")
    
    # Initialize resources
    settings = get_settings()
    writer_pool = BigQueryWriterPool(
        project_id=settings.gcp_project,
        dataset_id=settings.bq_dataset,
    )
    api_client = LoyaltyAPIClient()
    
    yield
    
    # Cleanup
    logger.info("application_shutting_down")
    if writer_pool:
        writer_pool.close_all()


app = FastAPI(
    title="The1 API Ingestion Service",
    description="Ingest data from Loyalty REST API to BigQuery",
    version="1.0.0",
    lifespan=lifespan,
)


# Request/Response models
class IngestResponse(BaseModel):
    """Standard ingestion response."""
    status: str
    records_processed: int
    message: str
    timestamp: str


class HealthResponse(BaseModel):
    """Health check response."""
    status: str
    service: str
    timestamp: str


class StatsResponse(BaseModel):
    """Statistics response."""
    writers: dict[str, Any]
    timestamp: str


# Endpoints
@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint."""
    return HealthResponse(
        status="healthy",
        service="the1-api-ingestion",
        timestamp=datetime.now(timezone.utc).isoformat(),
    )


@app.get("/stats", response_model=StatsResponse)
async def get_stats():
    """Get ingestion statistics."""
    if not writer_pool:
        raise HTTPException(status_code=503, detail="Service not initialized")
    
    return StatsResponse(
        writers=writer_pool.get_all_stats(),
        timestamp=datetime.now(timezone.utc).isoformat(),
    )


@app.post("/ingest/tiers", response_model=IngestResponse)
async def trigger_tiers_ingestion(background_tasks: BackgroundTasks):
    """Trigger tiers ingestion.
    
    Fetches all tier definitions and writes to BigQuery.
    Called by Cloud Scheduler (daily).
    """
    if not api_client or not writer_pool:
        raise HTTPException(status_code=503, detail="Service not initialized")
    
    try:
        result = await ingest_tiers(api_client, writer_pool)
        
        return IngestResponse(
            status="success",
            records_processed=result["records_processed"],
            message=f"Tiers ingestion completed",
            timestamp=datetime.now(timezone.utc).isoformat(),
        )
        
    except Exception as e:
        logger.error("tiers_ingestion_failed", error=str(e))
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/ingest/member/{member_id}", response_model=IngestResponse)
async def trigger_member_ingestion(member_id: str):
    """Trigger single member ingestion.
    
    Fetches member info and writes to BigQuery.
    Can be called on-demand or for specific members.
    """
    if not api_client or not writer_pool:
        raise HTTPException(status_code=503, detail="Service not initialized")
    
    try:
        result = await ingest_member(api_client, writer_pool, member_id)
        
        return IngestResponse(
            status="success",
            records_processed=result["records_processed"],
            message=f"Member {member_id} ingestion completed",
            timestamp=datetime.now(timezone.utc).isoformat(),
        )
        
    except Exception as e:
        logger.error("member_ingestion_failed", member_id=member_id, error=str(e))
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/ingest/member/{member_id}/accounts", response_model=IngestResponse)
async def trigger_member_accounts_ingestion(member_id: str):
    """Trigger member accounts ingestion.
    
    Fetches member account info and writes to BigQuery.
    """
    if not api_client or not writer_pool:
        raise HTTPException(status_code=503, detail="Service not initialized")
    
    try:
        result = await ingest_member_accounts(api_client, writer_pool, member_id)
        
        return IngestResponse(
            status="success",
            records_processed=result["records_processed"],
            message=f"Member {member_id} accounts ingestion completed",
            timestamp=datetime.now(timezone.utc).isoformat(),
        )
        
    except Exception as e:
        logger.error(
            "member_accounts_ingestion_failed", 
            member_id=member_id, 
            error=str(e)
        )
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/ingest/member/{member_id}/tier-events", response_model=IngestResponse)
async def trigger_member_tier_events_ingestion(member_id: str):
    """Trigger member tier events ingestion.
    
    Fetches member tier event history and writes to BigQuery.
    """
    if not api_client or not writer_pool:
        raise HTTPException(status_code=503, detail="Service not initialized")
    
    try:
        result = await ingest_member_tier_events(api_client, writer_pool, member_id)
        
        return IngestResponse(
            status="success",
            records_processed=result["records_processed"],
            message=f"Member {member_id} tier events ingestion completed",
            timestamp=datetime.now(timezone.utc).isoformat(),
        )
        
    except Exception as e:
        logger.error(
            "member_tier_events_ingestion_failed", 
            member_id=member_id, 
            error=str(e)
        )
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/ingest/members/batch", response_model=IngestResponse)
async def trigger_batch_members_ingestion(
    member_ids: list[str],
    include_accounts: bool = Query(default=True),
    include_tier_events: bool = Query(default=True),
):
    """Trigger batch members ingestion.
    
    Fetches multiple members and their related data.
    Useful for bulk operations.
    """
    if not api_client or not writer_pool:
        raise HTTPException(status_code=503, detail="Service not initialized")
    
    if len(member_ids) > 100:
        raise HTTPException(
            status_code=400, 
            detail="Maximum 100 members per batch"
        )
    
    try:
        result = await ingest_members_batch(
            api_client, 
            writer_pool, 
            member_ids,
            include_accounts=include_accounts,
            include_tier_events=include_tier_events,
        )
        
        return IngestResponse(
            status="success",
            records_processed=result["records_processed"],
            message=f"Batch ingestion completed for {len(member_ids)} members",
            timestamp=datetime.now(timezone.utc).isoformat(),
        )
        
    except Exception as e:
        logger.error("batch_members_ingestion_failed", error=str(e))
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/flush")
async def flush_writers():
    """Manually flush all writers to BigQuery."""
    if not writer_pool:
        raise HTTPException(status_code=503, detail="Service not initialized")
    
    results = writer_pool.flush_all()
    
    return {
        "status": "flushed",
        "results": {
            table: {"success": r.success, "rows_written": r.rows_written}
            for table, r in results.items()
        },
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


# Error handlers
@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    """Global exception handler."""
    logger.error(
        "unhandled_exception",
        path=request.url.path,
        method=request.method,
        error=str(exc),
    )
    return JSONResponse(
        status_code=500,
        content={
            "status": "error",
            "message": "Internal server error",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        },
    )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080)
