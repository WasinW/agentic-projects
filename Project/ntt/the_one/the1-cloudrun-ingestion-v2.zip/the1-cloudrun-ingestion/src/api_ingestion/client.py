"""REST API client for The1 Loyalty API."""

import time
from datetime import datetime, timezone
from typing import Any

import httpx
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type,
)
import structlog

from common import get_settings, get_api_credentials

logger = structlog.get_logger(__name__)


class APIError(Exception):
    """Base exception for API errors."""
    
    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code


class AuthenticationError(APIError):
    """Authentication failed."""
    pass


class RateLimitError(APIError):
    """Rate limit exceeded."""
    pass


class LoyaltyAPIClient:
    """Client for The1 Loyalty REST API.
    
    Handles authentication, request retries, and rate limiting.
    """

    def __init__(self):
        """Initialize API client."""
        self.settings = get_settings()
        self.base_url = self.settings.api_base_url
        self.api_gateway_id = self.settings.api_gateway_id
        self.timeout = self.settings.api_timeout_seconds
        
        # Token management
        self._access_token: str | None = None
        self._token_expires_at: datetime | None = None
        
        # HTTP client
        self._client = httpx.AsyncClient(
            timeout=httpx.Timeout(self.timeout),
            headers={
                "Content-Type": "application/json",
                "x-apigw-api-id": self.api_gateway_id,
            },
        )
        
        # Stats
        self._request_count = 0
        self._error_count = 0

    async def close(self):
        """Close HTTP client."""
        await self._client.aclose()

    async def __aenter__(self):
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.close()
        return False

    def _is_token_valid(self) -> bool:
        """Check if current token is still valid."""
        if not self._access_token or not self._token_expires_at:
            return False
        
        # Add 5 minute buffer
        buffer_seconds = 300
        return datetime.now(timezone.utc) < self._token_expires_at.replace(
            tzinfo=timezone.utc
        ) - buffer_seconds

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=10),
        retry=retry_if_exception_type((httpx.RequestError, httpx.TimeoutException)),
    )
    async def _authenticate(self) -> str:
        """Authenticate and get access token.
        
        Returns:
            Access token string
        """
        credentials = get_api_credentials()
        
        url = f"{self.base_url}/authentications/tokens"
        payload = {
            "clientId": credentials["clientId"],
            "clientSecret": credentials["clientSecret"],
        }
        
        logger.info("authenticating", url=url)
        
        response = await self._client.post(url, json=payload)
        
        if response.status_code != 200:
            raise AuthenticationError(
                f"Authentication failed: {response.text}",
                status_code=response.status_code
            )
        
        data = response.json()
        
        # Extract token (adjust based on actual response format)
        self._access_token = data.get("access_token") or data.get("token")
        
        # Parse expiration (adjust based on actual response format)
        expires_in = data.get("expires_in", 3600)  # Default 1 hour
        self._token_expires_at = datetime.now(timezone.utc) + \
            __import__("datetime").timedelta(seconds=expires_in)
        
        logger.info(
            "authentication_successful",
            expires_in=expires_in,
        )
        
        return self._access_token

    async def _ensure_authenticated(self) -> str:
        """Ensure we have a valid token.
        
        Returns:
            Valid access token
        """
        if not self._is_token_valid():
            await self._authenticate()
        return self._access_token

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=10),
        retry=retry_if_exception_type((httpx.RequestError, httpx.TimeoutException)),
    )
    async def _request(
        self,
        method: str,
        path: str,
        params: dict[str, Any] | None = None,
        json_data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make authenticated API request.
        
        Args:
            method: HTTP method
            path: API path (relative to base URL)
            params: Query parameters
            json_data: JSON body data
            
        Returns:
            Response JSON data
        """
        token = await self._ensure_authenticated()
        
        url = f"{self.base_url}{path}"
        headers = {"Authorization": f"Bearer {token}"}
        
        start_time = time.time()
        self._request_count += 1
        
        logger.debug(
            "api_request_start",
            method=method,
            path=path,
            params=params,
        )
        
        try:
            response = await self._client.request(
                method=method,
                url=url,
                headers=headers,
                params=params,
                json=json_data,
            )
            
            duration_ms = (time.time() - start_time) * 1000
            
            # Handle rate limiting
            if response.status_code == 429:
                retry_after = int(response.headers.get("Retry-After", 60))
                raise RateLimitError(
                    f"Rate limit exceeded. Retry after {retry_after}s",
                    status_code=429
                )
            
            # Handle auth errors (token might have expired)
            if response.status_code == 401:
                self._access_token = None
                raise AuthenticationError(
                    "Token expired or invalid",
                    status_code=401
                )
            
            # Handle other errors
            if response.status_code >= 400:
                self._error_count += 1
                raise APIError(
                    f"API error: {response.status_code} - {response.text}",
                    status_code=response.status_code
                )
            
            logger.info(
                "api_request_completed",
                method=method,
                path=path,
                status_code=response.status_code,
                duration_ms=round(duration_ms, 2),
            )
            
            return response.json()
            
        except Exception as e:
            self._error_count += 1
            logger.error(
                "api_request_failed",
                method=method,
                path=path,
                error=str(e),
            )
            raise

    # API Methods
    async def get_tiers(self) -> list[dict[str, Any]]:
        """Get all tier definitions.
        
        Returns:
            List of tier objects
        """
        response = await self._request("GET", "/loyalty/v2/tiers")
        
        # Adjust based on actual response structure
        return response.get("data", response.get("tiers", [response]))

    async def get_member(self, member_id: str) -> dict[str, Any]:
        """Get member information.
        
        Args:
            member_id: Member ID
            
        Returns:
            Member object
        """
        response = await self._request("GET", f"/loyalty/v2/members/{member_id}")
        return response.get("data", response)

    async def get_member_accounts(self, member_id: str) -> list[dict[str, Any]]:
        """Get member accounts.
        
        Args:
            member_id: Member ID
            
        Returns:
            List of account objects
        """
        response = await self._request(
            "GET", 
            f"/loyalty/v2/members/{member_id}/accounts"
        )
        return response.get("data", response.get("accounts", [response]))

    async def get_member_tier_events(self, member_id: str) -> list[dict[str, Any]]:
        """Get member tier event history.
        
        Args:
            member_id: Member ID
            
        Returns:
            List of tier event objects
        """
        response = await self._request(
            "GET",
            f"/loyalty/v2/members/{member_id}/tiers/events"
        )
        return response.get("data", response.get("events", [response]))

    def get_stats(self) -> dict[str, Any]:
        """Get client statistics.
        
        Returns:
            Dictionary with stats
        """
        return {
            "request_count": self._request_count,
            "error_count": self._error_count,
            "token_valid": self._is_token_valid(),
        }
