"""Data transformation utilities."""

import re
from datetime import datetime, timezone
from typing import Any, Callable

import structlog

logger = structlog.get_logger()


def flatten_dict(
    nested_dict: dict[str, Any],
    parent_key: str = "",
    separator: str = "_"
) -> dict[str, Any]:
    """Flatten nested dictionary.
    
    Args:
        nested_dict: Dictionary to flatten
        parent_key: Prefix for keys
        separator: Separator between keys
        
    Returns:
        Flattened dictionary
        
    Example:
        >>> flatten_dict({"a": {"b": 1, "c": 2}})
        {"a_b": 1, "a_c": 2}
    """
    items: list[tuple[str, Any]] = []
    
    for key, value in nested_dict.items():
        new_key = f"{parent_key}{separator}{key}" if parent_key else key
        
        if isinstance(value, dict):
            items.extend(flatten_dict(value, new_key, separator).items())
        elif isinstance(value, list):
            # Convert lists to JSON strings for BigQuery
            import json
            items.append((new_key, json.dumps(value)))
        else:
            items.append((new_key, value))
    
    return dict(items)


def snake_case(name: str) -> str:
    """Convert string to snake_case.
    
    Args:
        name: String to convert
        
    Returns:
        Snake case string
        
    Example:
        >>> snake_case("camelCase")
        "camel_case"
        >>> snake_case("PascalCase")
        "pascal_case"
    """
    # Insert underscore before uppercase letters
    s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
    # Insert underscore before uppercase letters preceded by lowercase
    s2 = re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1)
    return s2.lower()


def convert_keys_to_snake_case(data: dict[str, Any]) -> dict[str, Any]:
    """Convert all dictionary keys to snake_case.
    
    Args:
        data: Dictionary with any case keys
        
    Returns:
        Dictionary with snake_case keys
    """
    result = {}
    
    for key, value in data.items():
        new_key = snake_case(key)
        
        if isinstance(value, dict):
            result[new_key] = convert_keys_to_snake_case(value)
        elif isinstance(value, list):
            result[new_key] = [
                convert_keys_to_snake_case(item) if isinstance(item, dict) else item
                for item in value
            ]
        else:
            result[new_key] = value
    
    return result


def add_metadata(
    record: dict[str, Any],
    source: str,
    source_timestamp: datetime | None = None
) -> dict[str, Any]:
    """Add ingestion metadata to record.
    
    Args:
        record: Original record
        source: Source identifier (e.g., "api", "kafka")
        source_timestamp: Original timestamp from source
        
    Returns:
        Record with metadata fields
    """
    now = datetime.now(timezone.utc)
    
    return {
        **record,
        "_source": source,
        "_ingested_at": now.isoformat(),
        "_source_timestamp": source_timestamp.isoformat() if source_timestamp else None,
    }


def parse_iso_datetime(value: str | None) -> datetime | None:
    """Parse ISO datetime string.
    
    Args:
        value: ISO datetime string
        
    Returns:
        Parsed datetime or None
    """
    if not value:
        return None
    
    try:
        # Handle various ISO formats
        if value.endswith("Z"):
            value = value[:-1] + "+00:00"
        return datetime.fromisoformat(value)
    except (ValueError, TypeError):
        logger.warning("datetime_parse_failed", value=value)
        return None


def safe_get(
    data: dict[str, Any],
    *keys: str,
    default: Any = None
) -> Any:
    """Safely get nested dictionary value.
    
    Args:
        data: Dictionary to search
        *keys: Keys path
        default: Default value if not found
        
    Returns:
        Value at path or default
        
    Example:
        >>> safe_get({"a": {"b": 1}}, "a", "b")
        1
        >>> safe_get({"a": {"b": 1}}, "a", "c", default=0)
        0
    """
    result = data
    
    for key in keys:
        if isinstance(result, dict):
            result = result.get(key, default)
        else:
            return default
    
    return result


def apply_field_mapping(
    record: dict[str, Any],
    mapping: dict[str, str]
) -> dict[str, Any]:
    """Apply field name mapping to record.
    
    Args:
        record: Original record
        mapping: Dict of original_name -> new_name
        
    Returns:
        Record with renamed fields
    """
    result = {}
    
    for key, value in record.items():
        new_key = mapping.get(key, key)
        result[new_key] = value
    
    return result


def cast_types(
    record: dict[str, Any],
    type_mapping: dict[str, str]
) -> dict[str, Any]:
    """Cast field values to specified types.
    
    Args:
        record: Original record
        type_mapping: Dict of field_name -> type_name
        
    Returns:
        Record with casted types
        
    Supported types: string, integer, float, boolean, datetime
    """
    result = {}
    
    type_casters: dict[str, Callable] = {
        "string": str,
        "integer": lambda x: int(x) if x is not None else None,
        "float": lambda x: float(x) if x is not None else None,
        "boolean": lambda x: bool(x) if x is not None else None,
        "datetime": parse_iso_datetime,
    }
    
    for key, value in record.items():
        if key in type_mapping:
            target_type = type_mapping[key]
            caster = type_casters.get(target_type)
            
            if caster:
                try:
                    result[key] = caster(value)
                except (ValueError, TypeError) as e:
                    logger.warning(
                        "type_cast_failed",
                        field=key,
                        value=value,
                        target_type=target_type,
                        error=str(e)
                    )
                    result[key] = value
            else:
                result[key] = value
        else:
            result[key] = value
    
    return result


def filter_fields(
    record: dict[str, Any],
    include: list[str] | None = None,
    exclude: list[str] | None = None
) -> dict[str, Any]:
    """Filter record fields.
    
    Args:
        record: Original record
        include: Fields to include (if set, only these)
        exclude: Fields to exclude
        
    Returns:
        Filtered record
    """
    result = record.copy()
    
    if include:
        result = {k: v for k, v in result.items() if k in include}
    
    if exclude:
        result = {k: v for k, v in result.items() if k not in exclude}
    
    return result


class RecordTransformer:
    """Configurable record transformer."""

    def __init__(
        self,
        flatten: bool = False,
        snake_case_keys: bool = True,
        field_mapping: dict[str, str] | None = None,
        type_mapping: dict[str, str] | None = None,
        include_fields: list[str] | None = None,
        exclude_fields: list[str] | None = None,
        source: str = "unknown",
    ):
        """Initialize transformer.
        
        Args:
            flatten: Whether to flatten nested dicts
            snake_case_keys: Whether to convert keys to snake_case
            field_mapping: Field name mapping
            type_mapping: Type casting mapping
            include_fields: Fields to include
            exclude_fields: Fields to exclude
            source: Source identifier for metadata
        """
        self.flatten = flatten
        self.snake_case_keys = snake_case_keys
        self.field_mapping = field_mapping or {}
        self.type_mapping = type_mapping or {}
        self.include_fields = include_fields
        self.exclude_fields = exclude_fields
        self.source = source

    def transform(
        self,
        record: dict[str, Any],
        source_timestamp: datetime | None = None
    ) -> dict[str, Any]:
        """Apply all transformations to record.
        
        Args:
            record: Original record
            source_timestamp: Original timestamp from source
            
        Returns:
            Transformed record
        """
        result = record.copy()
        
        # Flatten if needed
        if self.flatten:
            result = flatten_dict(result)
        
        # Convert to snake_case
        if self.snake_case_keys:
            result = convert_keys_to_snake_case(result)
        
        # Apply field mapping
        if self.field_mapping:
            result = apply_field_mapping(result, self.field_mapping)
        
        # Cast types
        if self.type_mapping:
            result = cast_types(result, self.type_mapping)
        
        # Filter fields
        result = filter_fields(
            result,
            include=self.include_fields,
            exclude=self.exclude_fields
        )
        
        # Add metadata
        result = add_metadata(result, self.source, source_timestamp)
        
        return result

    def transform_batch(
        self,
        records: list[dict[str, Any]],
        source_timestamp: datetime | None = None
    ) -> list[dict[str, Any]]:
        """Transform multiple records.
        
        Args:
            records: List of records
            source_timestamp: Original timestamp from source
            
        Returns:
            List of transformed records
        """
        return [self.transform(r, source_timestamp) for r in records]
