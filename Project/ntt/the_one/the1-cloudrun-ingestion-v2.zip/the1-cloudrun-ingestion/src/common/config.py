"""Configuration management for The1 Cloud Run Ingestion."""

import os
from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml
from pydantic import Field
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    # GCP Settings
    gcp_project: str = Field(default="", env="GCP_PROJECT")
    gcp_region: str = Field(default="asia-southeast1", env="GCP_REGION")

    # BigQuery Settings
    bq_dataset: str = Field(default="the1_loyalty_raw", env="BQ_DATASET")
    bq_location: str = Field(default="asia-southeast1", env="BQ_LOCATION")

    # API Settings
    api_base_url: str = Field(
        default="https://vpce-09b5b0e1633f97118-9fc5jzij.execute-api.ap-southeast-1.vpce.amazonaws.com/prod",
        env="API_BASE_URL",
    )
    api_gateway_id: str = Field(default="ee2j2kx5tb", env="API_GATEWAY_ID")
    api_secret_name: str = Field(default="prod/api/authenToken", env="API_SECRET_NAME")
    api_timeout_seconds: int = Field(default=30, env="API_TIMEOUT_SECONDS")

    # Kafka Settings
    kafka_bootstrap_servers: str = Field(default="", env="KAFKA_BOOTSTRAP_SERVERS")
    kafka_secret_name: str = Field(
        default="prod/the1ConfluentKafka", env="KAFKA_SECRET_NAME"
    )
    kafka_group_id: str = Field(
        default="the1-cloudrun-ingestion", env="KAFKA_GROUP_ID"
    )
    kafka_auto_offset_reset: str = Field(default="earliest", env="KAFKA_AUTO_OFFSET_RESET")

    # BigQuery Writer Settings
    bq_batch_size: int = Field(default=500, env="BQ_BATCH_SIZE")
    bq_flush_interval_seconds: int = Field(default=10, env="BQ_FLUSH_INTERVAL_SECONDS")
    bq_max_batch_bytes: int = Field(default=1_000_000, env="BQ_MAX_BATCH_BYTES")  # 1MB

    # Logging
    log_level: str = Field(default="INFO", env="LOG_LEVEL")
    
    # Feature Flags
    enable_metrics: bool = Field(default=True, env="ENABLE_METRICS")
    enable_dead_letter: bool = Field(default=True, env="ENABLE_DEAD_LETTER")

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


@lru_cache
def get_settings() -> Settings:
    """Get cached settings instance."""
    return Settings()


def load_yaml_config(config_name: str) -> dict[str, Any]:
    """Load YAML configuration file.
    
    Args:
        config_name: Name of config file (without .yaml extension)
        
    Returns:
        Parsed YAML content as dictionary
    """
    # Look in multiple locations
    config_paths = [
        Path(__file__).parent.parent / "configs" / f"{config_name}.yaml",
        Path("/app/configs") / f"{config_name}.yaml",
        Path("configs") / f"{config_name}.yaml",
    ]
    
    for config_path in config_paths:
        if config_path.exists():
            with open(config_path, "r") as f:
                return yaml.safe_load(f)
    
    raise FileNotFoundError(
        f"Config file {config_name}.yaml not found in any of: {config_paths}"
    )


def get_table_config(table_name: str) -> dict[str, Any]:
    """Get BigQuery table configuration.
    
    Args:
        table_name: Name of the table
        
    Returns:
        Table configuration including schema
    """
    schemas_config = load_yaml_config("bigquery_schemas")
    
    if table_name not in schemas_config.get("tables", {}):
        raise ValueError(f"Unknown table: {table_name}")
    
    return schemas_config["tables"][table_name]


def get_api_endpoint_config(endpoint_name: str) -> dict[str, Any]:
    """Get API endpoint configuration.
    
    Args:
        endpoint_name: Name of the endpoint
        
    Returns:
        Endpoint configuration
    """
    api_config = load_yaml_config("api_endpoints")
    
    if endpoint_name not in api_config.get("endpoints", {}):
        raise ValueError(f"Unknown endpoint: {endpoint_name}")
    
    return api_config["endpoints"][endpoint_name]


def get_kafka_topic_config(topic_name: str) -> dict[str, Any]:
    """Get Kafka topic configuration.
    
    Args:
        topic_name: Name of the topic
        
    Returns:
        Topic configuration
    """
    kafka_config = load_yaml_config("kafka_topics")
    
    if topic_name not in kafka_config.get("topics", {}):
        raise ValueError(f"Unknown topic: {topic_name}")
    
    return kafka_config["topics"][topic_name]
