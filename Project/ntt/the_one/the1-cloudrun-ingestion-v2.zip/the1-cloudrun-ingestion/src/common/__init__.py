"""Common utilities for The1 Cloud Run Ingestion."""

from .config import get_settings, load_yaml_config, get_table_config
from .secrets import get_secret_manager_client, get_api_credentials, get_kafka_credentials
from .bigquery_writer import BigQueryWriter, BigQueryWriterPool, WriteResult
from .transformer import RecordTransformer, flatten_dict, convert_keys_to_snake_case
from .logging_config import setup_logging, get_logger, LogContext

__all__ = [
    # Config
    "get_settings",
    "load_yaml_config",
    "get_table_config",
    # Secrets
    "get_secret_manager_client",
    "get_api_credentials",
    "get_kafka_credentials",
    # BigQuery
    "BigQueryWriter",
    "BigQueryWriterPool",
    "WriteResult",
    # Transformer
    "RecordTransformer",
    "flatten_dict",
    "convert_keys_to_snake_case",
    # Logging
    "setup_logging",
    "get_logger",
    "LogContext",
]
