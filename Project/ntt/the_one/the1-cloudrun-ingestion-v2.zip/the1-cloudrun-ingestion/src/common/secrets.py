"""Secret Manager client for secure credential access."""

import json
from functools import lru_cache
from typing import Any

from google.cloud import secretmanager
import structlog

from .config import get_settings

logger = structlog.get_logger()


class SecretManagerClient:
    """Client for accessing secrets from Google Cloud Secret Manager."""

    def __init__(self, project_id: str | None = None):
        """Initialize Secret Manager client.
        
        Args:
            project_id: GCP project ID. If None, uses settings.
        """
        self.project_id = project_id or get_settings().gcp_project
        self._client = secretmanager.SecretManagerServiceClient()
        self._cache: dict[str, Any] = {}

    def get_secret(
        self, 
        secret_name: str, 
        version: str = "latest",
        parse_json: bool = True
    ) -> Any:
        """Get secret value from Secret Manager.
        
        Args:
            secret_name: Name of the secret
            version: Secret version (default: latest)
            parse_json: If True, parse value as JSON
            
        Returns:
            Secret value (parsed as JSON if parse_json=True)
        """
        cache_key = f"{secret_name}:{version}"
        
        if cache_key in self._cache:
            return self._cache[cache_key]
        
        try:
            # Build the resource name
            name = f"projects/{self.project_id}/secrets/{secret_name}/versions/{version}"
            
            # Access the secret
            response = self._client.access_secret_version(request={"name": name})
            secret_value = response.payload.data.decode("UTF-8")
            
            # Parse JSON if requested
            if parse_json:
                try:
                    secret_value = json.loads(secret_value)
                except json.JSONDecodeError:
                    # Not JSON, return as string
                    pass
            
            # Cache the result
            self._cache[cache_key] = secret_value
            
            logger.info("secret_accessed", secret_name=secret_name, version=version)
            return secret_value
            
        except Exception as e:
            logger.error(
                "secret_access_failed",
                secret_name=secret_name,
                version=version,
                error=str(e)
            )
            raise

    def clear_cache(self):
        """Clear the secrets cache."""
        self._cache.clear()


@lru_cache
def get_secret_manager_client() -> SecretManagerClient:
    """Get cached Secret Manager client instance."""
    return SecretManagerClient()


def get_api_credentials() -> dict[str, str]:
    """Get API credentials from Secret Manager.
    
    Returns:
        Dictionary with clientId and clientSecret
    """
    settings = get_settings()
    client = get_secret_manager_client()
    
    credentials = client.get_secret(settings.api_secret_name)
    
    # Expected format: {"clientId": "...", "clientSecret": "..."}
    if not isinstance(credentials, dict):
        raise ValueError(
            f"Invalid API credentials format. Expected dict, got {type(credentials)}"
        )
    
    required_keys = ["clientId", "clientSecret"]
    missing_keys = [k for k in required_keys if k not in credentials]
    
    if missing_keys:
        raise ValueError(f"Missing keys in API credentials: {missing_keys}")
    
    return credentials


def get_kafka_credentials() -> dict[str, str]:
    """Get Kafka credentials from Secret Manager.
    
    Returns:
        Dictionary with bootstrap_servers, api_key, api_secret
    """
    settings = get_settings()
    client = get_secret_manager_client()
    
    credentials = client.get_secret(settings.kafka_secret_name)
    
    # Expected format: {"bootstrap_servers": "...", "api_key": "...", "api_secret": "..."}
    if not isinstance(credentials, dict):
        raise ValueError(
            f"Invalid Kafka credentials format. Expected dict, got {type(credentials)}"
        )
    
    required_keys = ["bootstrap_servers", "api_key", "api_secret"]
    missing_keys = [k for k in required_keys if k not in credentials]
    
    if missing_keys:
        raise ValueError(f"Missing keys in Kafka credentials: {missing_keys}")
    
    return credentials
