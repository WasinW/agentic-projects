"""BigQuery Storage Write API wrapper for high-throughput ingestion."""

import time
import threading
from datetime import datetime, timezone
from typing import Any, Callable
from queue import Queue, Empty
from dataclasses import dataclass, field

from google.cloud import bigquery
from google.cloud.bigquery_storage_v1 import BigQueryWriteClient, types
from google.protobuf import descriptor_pb2
import structlog

from .config import get_settings, get_table_config

logger = structlog.get_logger()


@dataclass
class WriteResult:
    """Result of a write operation."""
    success: bool
    rows_written: int
    errors: list[str] = field(default_factory=list)
    offset: int | None = None


class BigQueryWriter:
    """High-performance BigQuery writer using Storage Write API.
    
    Features:
    - Buffered writes with configurable batch size
    - Auto-flush based on time or size
    - Thread-safe operation
    - Exactly-once semantics with committed streams
    """

    def __init__(
        self,
        project_id: str,
        dataset_id: str,
        table_id: str,
        batch_size: int = 500,
        flush_interval_seconds: int = 10,
        max_batch_bytes: int = 1_000_000,
    ):
        """Initialize BigQuery writer.
        
        Args:
            project_id: GCP project ID
            dataset_id: BigQuery dataset ID
            table_id: BigQuery table ID
            batch_size: Max records per batch
            flush_interval_seconds: Auto-flush interval
            max_batch_bytes: Max batch size in bytes
        """
        self.project_id = project_id
        self.dataset_id = dataset_id
        self.table_id = table_id
        self.batch_size = batch_size
        self.flush_interval_seconds = flush_interval_seconds
        self.max_batch_bytes = max_batch_bytes
        
        # Clients
        self._bq_client = bigquery.Client(project=project_id)
        self._write_client = BigQueryWriteClient()
        
        # Buffer
        self._buffer: list[dict[str, Any]] = []
        self._buffer_lock = threading.Lock()
        self._buffer_bytes = 0
        
        # Write stream
        self._write_stream: types.WriteStream | None = None
        self._parent = f"projects/{project_id}/datasets/{dataset_id}/tables/{table_id}"
        
        # Stats
        self._total_rows_written = 0
        self._total_batches_written = 0
        self._last_flush_time = time.time()
        
        # Auto-flush thread
        self._auto_flush_enabled = False
        self._auto_flush_thread: threading.Thread | None = None
        self._stop_event = threading.Event()

    @property
    def table_ref(self) -> str:
        """Get full table reference."""
        return f"{self.project_id}.{self.dataset_id}.{self.table_id}"

    def _create_write_stream(self) -> types.WriteStream:
        """Create a new write stream."""
        write_stream = types.WriteStream()
        write_stream.type_ = types.WriteStream.Type.COMMITTED
        
        request = types.CreateWriteStreamRequest(
            parent=self._parent,
            write_stream=write_stream,
        )
        
        self._write_stream = self._write_client.create_write_stream(request=request)
        logger.info(
            "write_stream_created",
            stream_name=self._write_stream.name,
            table=self.table_ref
        )
        return self._write_stream

    def _get_or_create_stream(self) -> types.WriteStream:
        """Get existing stream or create new one."""
        if self._write_stream is None:
            self._create_write_stream()
        return self._write_stream

    def add(self, record: dict[str, Any]) -> None:
        """Add a record to the buffer.
        
        Args:
            record: Dictionary representing a row
        """
        # Add metadata
        record_with_meta = {
            **record,
            "_ingested_at": datetime.now(timezone.utc).isoformat(),
        }
        
        record_bytes = len(str(record_with_meta).encode("utf-8"))
        
        with self._buffer_lock:
            self._buffer.append(record_with_meta)
            self._buffer_bytes += record_bytes
            
            # Check if we should flush
            should_flush = (
                len(self._buffer) >= self.batch_size or
                self._buffer_bytes >= self.max_batch_bytes
            )
        
        if should_flush:
            self.flush()

    def add_batch(self, records: list[dict[str, Any]]) -> None:
        """Add multiple records to the buffer.
        
        Args:
            records: List of dictionaries representing rows
        """
        for record in records:
            self.add(record)

    def flush(self) -> WriteResult:
        """Flush buffer to BigQuery.
        
        Returns:
            WriteResult with status and stats
        """
        with self._buffer_lock:
            if not self._buffer:
                return WriteResult(success=True, rows_written=0)
            
            records_to_write = self._buffer.copy()
            self._buffer.clear()
            self._buffer_bytes = 0
        
        try:
            result = self._write_records(records_to_write)
            
            self._total_rows_written += result.rows_written
            self._total_batches_written += 1
            self._last_flush_time = time.time()
            
            logger.info(
                "batch_written",
                table=self.table_ref,
                rows=result.rows_written,
                total_rows=self._total_rows_written,
                total_batches=self._total_batches_written
            )
            
            return result
            
        except Exception as e:
            logger.error(
                "batch_write_failed",
                table=self.table_ref,
                rows=len(records_to_write),
                error=str(e)
            )
            
            # Put records back in buffer for retry
            with self._buffer_lock:
                self._buffer = records_to_write + self._buffer
            
            return WriteResult(
                success=False,
                rows_written=0,
                errors=[str(e)]
            )

    def _write_records(self, records: list[dict[str, Any]]) -> WriteResult:
        """Write records using standard BigQuery client (fallback).
        
        For production, consider using the full Storage Write API with
        protobuf serialization for better performance.
        
        Args:
            records: List of records to write
            
        Returns:
            WriteResult with status
        """
        table_ref = self._bq_client.dataset(self.dataset_id).table(self.table_id)
        
        errors = self._bq_client.insert_rows_json(
            table_ref,
            records,
            row_ids=[None] * len(records)  # Auto-generate row IDs
        )
        
        if errors:
            error_messages = [str(e) for e in errors]
            return WriteResult(
                success=False,
                rows_written=len(records) - len(errors),
                errors=error_messages
            )
        
        return WriteResult(success=True, rows_written=len(records))

    def start_auto_flush(self) -> None:
        """Start auto-flush background thread."""
        if self._auto_flush_enabled:
            return
        
        self._auto_flush_enabled = True
        self._stop_event.clear()
        
        self._auto_flush_thread = threading.Thread(
            target=self._auto_flush_loop,
            daemon=True
        )
        self._auto_flush_thread.start()
        
        logger.info("auto_flush_started", interval=self.flush_interval_seconds)

    def stop_auto_flush(self) -> None:
        """Stop auto-flush and flush remaining records."""
        if not self._auto_flush_enabled:
            return
        
        self._stop_event.set()
        if self._auto_flush_thread:
            self._auto_flush_thread.join(timeout=5)
        
        self._auto_flush_enabled = False
        
        # Final flush
        self.flush()
        
        logger.info("auto_flush_stopped")

    def _auto_flush_loop(self) -> None:
        """Background thread for periodic flushing."""
        while not self._stop_event.is_set():
            time.sleep(1)  # Check every second
            
            time_since_flush = time.time() - self._last_flush_time
            
            with self._buffer_lock:
                has_records = len(self._buffer) > 0
            
            if has_records and time_since_flush >= self.flush_interval_seconds:
                self.flush()

    def close(self) -> None:
        """Close writer and flush remaining records."""
        self.stop_auto_flush()
        
        # Close write stream if exists
        if self._write_stream:
            try:
                self._write_client.finalize_write_stream(
                    name=self._write_stream.name
                )
            except Exception as e:
                logger.warning("stream_finalize_error", error=str(e))
        
        logger.info(
            "writer_closed",
            table=self.table_ref,
            total_rows=self._total_rows_written,
            total_batches=self._total_batches_written
        )

    def __enter__(self):
        """Context manager entry."""
        self.start_auto_flush()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()
        return False

    def get_stats(self) -> dict[str, Any]:
        """Get writer statistics.
        
        Returns:
            Dictionary with stats
        """
        with self._buffer_lock:
            buffer_size = len(self._buffer)
        
        return {
            "table": self.table_ref,
            "total_rows_written": self._total_rows_written,
            "total_batches_written": self._total_batches_written,
            "buffer_size": buffer_size,
            "last_flush_time": self._last_flush_time,
        }


class BigQueryWriterPool:
    """Pool of BigQuery writers for multiple tables."""

    def __init__(self, project_id: str | None = None, dataset_id: str | None = None):
        """Initialize writer pool.
        
        Args:
            project_id: GCP project ID
            dataset_id: BigQuery dataset ID
        """
        settings = get_settings()
        self.project_id = project_id or settings.gcp_project
        self.dataset_id = dataset_id or settings.bq_dataset
        
        self._writers: dict[str, BigQueryWriter] = {}
        self._lock = threading.Lock()

    def get_writer(self, table_id: str) -> BigQueryWriter:
        """Get or create writer for a table.
        
        Args:
            table_id: Table ID
            
        Returns:
            BigQueryWriter instance
        """
        with self._lock:
            if table_id not in self._writers:
                settings = get_settings()
                self._writers[table_id] = BigQueryWriter(
                    project_id=self.project_id,
                    dataset_id=self.dataset_id,
                    table_id=table_id,
                    batch_size=settings.bq_batch_size,
                    flush_interval_seconds=settings.bq_flush_interval_seconds,
                    max_batch_bytes=settings.bq_max_batch_bytes,
                )
                self._writers[table_id].start_auto_flush()
            
            return self._writers[table_id]

    def flush_all(self) -> dict[str, WriteResult]:
        """Flush all writers.
        
        Returns:
            Dictionary of table_id -> WriteResult
        """
        results = {}
        with self._lock:
            for table_id, writer in self._writers.items():
                results[table_id] = writer.flush()
        return results

    def close_all(self) -> None:
        """Close all writers."""
        with self._lock:
            for writer in self._writers.values():
                writer.close()
            self._writers.clear()

    def get_all_stats(self) -> dict[str, dict[str, Any]]:
        """Get stats for all writers.
        
        Returns:
            Dictionary of table_id -> stats
        """
        stats = {}
        with self._lock:
            for table_id, writer in self._writers.items():
                stats[table_id] = writer.get_stats()
        return stats

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close_all()
        return False
