"""
Pipeline Design Pattern Implementation for The1 Data Pipeline

Patterns Used:
1. Pipeline (Pipes & Filters) - Main architecture
2. Strategy - Swappable transformation strategies
3. Template Method - Base processor skeleton
4. Protocol/Interface - Abstraction for stages

Flow: Kafka → Validate → Enrich (API) → Transform → Write (BigQuery)
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Generic, TypeVar, Protocol, Optional
from enum import Enum
import asyncio
import structlog

logger = structlog.get_logger(__name__)

# =============================================================================
# 1. DATA MODELS (Avoid Primitive Obsession)
# =============================================================================

class ProcessingStatus(Enum):
    """Status of message processing."""
    SUCCESS = "success"
    SKIPPED = "skipped"
    FAILED = "failed"
    ENRICHMENT_FAILED = "enrichment_failed"


@dataclass
class KafkaMessage:
    """Raw Kafka message wrapper."""
    topic: str
    partition: int
    offset: int
    key: Optional[str]
    value: dict[str, Any]
    timestamp: Optional[int] = None


@dataclass
class ProcessingContext:
    """Context passed through pipeline stages.
    
    This accumulates data as it flows through the pipeline.
    """
    # Original message
    raw_message: KafkaMessage
    
    # Enriched data from API
    enriched_data: dict[str, Any] = field(default_factory=dict)
    
    # Transformed data ready for BigQuery
    transformed_data: dict[str, Any] = field(default_factory=dict)
    
    # Processing metadata
    status: ProcessingStatus = ProcessingStatus.SUCCESS
    errors: list[str] = field(default_factory=list)
    started_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    
    # Flags for conditional processing
    skip_enrichment: bool = False
    skip_transformation: bool = False
    
    @property
    def member_id(self) -> Optional[str]:
        """Extract member_id from message."""
        return self.raw_message.value.get("member_id")
    
    @property
    def topic(self) -> str:
        """Get topic name."""
        return self.raw_message.topic


@dataclass
class ProcessingResult:
    """Result of pipeline processing."""
    context: ProcessingContext
    success: bool
    duration_ms: float
    stages_executed: list[str]


# =============================================================================
# 2. PIPELINE STAGE PROTOCOL (Interface)
# =============================================================================

T = TypeVar('T')

class PipelineStage(Protocol):
    """Protocol for pipeline stages.
    
    Each stage:
    - Receives ProcessingContext
    - Modifies or enriches the context
    - Returns the (possibly modified) context
    - Can mark context as failed/skipped
    """
    
    @property
    def name(self) -> str:
        """Stage name for logging."""
        ...
    
    async def process(self, context: ProcessingContext) -> ProcessingContext:
        """Process the context and return modified context."""
        ...
    
    def should_skip(self, context: ProcessingContext) -> bool:
        """Check if this stage should be skipped."""
        ...


# =============================================================================
# 3. ABSTRACT BASE STAGE (Template Method Pattern)
# =============================================================================

class BaseStage(ABC):
    """Abstract base class for pipeline stages.
    
    Implements Template Method pattern:
    - process() is the template method
    - _execute() is the hook for subclasses
    """
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Stage name."""
        pass
    
    def should_skip(self, context: ProcessingContext) -> bool:
        """Default: don't skip unless already failed."""
        return context.status == ProcessingStatus.FAILED
    
    async def process(self, context: ProcessingContext) -> ProcessingContext:
        """Template method - defines processing skeleton."""
        # Pre-check
        if self.should_skip(context):
            logger.debug(f"skipping_stage", stage=self.name, reason="skip_condition_met")
            return context
        
        try:
            # Hook method - implemented by subclasses
            context = await self._execute(context)
            
            logger.info(
                "stage_completed",
                stage=self.name,
                member_id=context.member_id,
            )
            
        except Exception as e:
            context.status = ProcessingStatus.FAILED
            context.errors.append(f"{self.name}: {str(e)}")
            logger.error(
                "stage_failed",
                stage=self.name,
                error=str(e),
            )
        
        return context
    
    @abstractmethod
    async def _execute(self, context: ProcessingContext) -> ProcessingContext:
        """Hook method - implement actual stage logic."""
        pass


# =============================================================================
# 4. CONCRETE STAGES
# =============================================================================

class ValidationStage(BaseStage):
    """Validates incoming Kafka message."""
    
    name = "validation"
    
    def __init__(self, required_fields: list[str] | None = None):
        self.required_fields = required_fields or ["member_id"]
    
    async def _execute(self, context: ProcessingContext) -> ProcessingContext:
        message_value = context.raw_message.value
        
        # Check required fields
        missing_fields = [
            f for f in self.required_fields 
            if f not in message_value or message_value[f] is None
        ]
        
        if missing_fields:
            context.status = ProcessingStatus.FAILED
            context.errors.append(f"Missing required fields: {missing_fields}")
            return context
        
        return context


class EnrichmentStage(BaseStage):
    """Enriches message with data from external API.
    
    This is where we call the Loyalty API to get additional info.
    """
    
    name = "enrichment"
    
    def __init__(self, api_client: Any):
        """
        Args:
            api_client: LoyaltyAPIClient instance for API calls
        """
        self.api_client = api_client
    
    def should_skip(self, context: ProcessingContext) -> bool:
        """Skip if marked or already failed."""
        return (
            super().should_skip(context) or 
            context.skip_enrichment
        )
    
    async def _execute(self, context: ProcessingContext) -> ProcessingContext:
        member_id = context.member_id
        
        if not member_id:
            context.skip_enrichment = True
            return context
        
        try:
            # Call API to get additional member info
            member_info = await self.api_client.get_member(member_id)
            accounts = await self.api_client.get_member_accounts(member_id)
            
            # Store enriched data in context
            context.enriched_data = {
                "member_info": member_info,
                "accounts": accounts,
                "enriched_at": datetime.now(timezone.utc).isoformat(),
            }
            
        except Exception as e:
            # Enrichment failure is non-fatal - continue with original data
            context.status = ProcessingStatus.ENRICHMENT_FAILED
            context.errors.append(f"Enrichment failed: {str(e)}")
            logger.warning(
                "enrichment_failed_continuing",
                member_id=member_id,
                error=str(e),
            )
        
        return context


# =============================================================================
# 5. STRATEGY PATTERN - Transformation Strategies
# =============================================================================

class TransformStrategy(ABC):
    """Abstract transformation strategy.
    
    Different topics can have different transformation logic.
    """
    
    @abstractmethod
    def transform(
        self, 
        message: dict[str, Any], 
        enriched: dict[str, Any]
    ) -> dict[str, Any]:
        """Transform message with enriched data."""
        pass


class UpgradeTransformStrategy(TransformStrategy):
    """Transformation strategy for member upgrades."""
    
    def transform(
        self, 
        message: dict[str, Any], 
        enriched: dict[str, Any]
    ) -> dict[str, Any]:
        """Transform upgrade event."""
        member_info = enriched.get("member_info", {})
        
        return {
            "event_type": "upgrade",
            "member_id": message.get("member_id"),
            "previous_tier_id": message.get("previous_tier_id"),
            "new_tier_id": message.get("new_tier_id"),
            "upgraded_at": message.get("upgraded_at"),
            "reason": message.get("reason"),
            "points_at_upgrade": message.get("points_at_upgrade"),
            # Enriched fields
            "member_name": member_info.get("first_name"),
            "member_status": member_info.get("status"),
            "total_accounts": len(enriched.get("accounts", [])),
            # Metadata
            "_processed_at": datetime.now(timezone.utc).isoformat(),
        }


class DowngradeTransformStrategy(TransformStrategy):
    """Transformation strategy for member downgrades."""
    
    def transform(
        self, 
        message: dict[str, Any], 
        enriched: dict[str, Any]
    ) -> dict[str, Any]:
        """Transform downgrade event."""
        member_info = enriched.get("member_info", {})
        
        return {
            "event_type": "downgrade",
            "member_id": message.get("member_id"),
            "previous_tier_id": message.get("previous_tier_id"),
            "new_tier_id": message.get("new_tier_id"),
            "downgraded_at": message.get("downgraded_at"),
            "reason": message.get("reason"),
            "points_at_downgrade": message.get("points_at_downgrade"),
            # Enriched fields
            "member_name": member_info.get("first_name"),
            "member_status": member_info.get("status"),
            # Metadata
            "_processed_at": datetime.now(timezone.utc).isoformat(),
        }


class PassthroughTransformStrategy(TransformStrategy):
    """No transformation - pass through with metadata."""
    
    def transform(
        self, 
        message: dict[str, Any], 
        enriched: dict[str, Any]
    ) -> dict[str, Any]:
        """Pass through with minimal transformation."""
        return {
            **message,
            "_enriched": bool(enriched),
            "_processed_at": datetime.now(timezone.utc).isoformat(),
        }


# Strategy Registry (could use Factory pattern here)
TRANSFORM_STRATEGIES: dict[str, TransformStrategy] = {
    "loyalty.members.upgraded": UpgradeTransformStrategy(),
    "loyalty.members.downgraded": DowngradeTransformStrategy(),
    "default": PassthroughTransformStrategy(),
}


class TransformationStage(BaseStage):
    """Transformation stage using Strategy pattern."""
    
    name = "transformation"
    
    def __init__(self, strategies: dict[str, TransformStrategy] | None = None):
        self.strategies = strategies or TRANSFORM_STRATEGIES
    
    def should_skip(self, context: ProcessingContext) -> bool:
        return (
            super().should_skip(context) or 
            context.skip_transformation
        )
    
    async def _execute(self, context: ProcessingContext) -> ProcessingContext:
        # Get strategy for this topic
        strategy = self.strategies.get(
            context.topic, 
            self.strategies.get("default")
        )
        
        if not strategy:
            context.errors.append(f"No transform strategy for topic: {context.topic}")
            return context
        
        # Apply transformation
        context.transformed_data = strategy.transform(
            message=context.raw_message.value,
            enriched=context.enriched_data,
        )
        
        return context


class BigQueryWriteStage(BaseStage):
    """Writes transformed data to BigQuery."""
    
    name = "bigquery_write"
    
    def __init__(self, writer_pool: Any, topic_table_mapping: dict[str, str]):
        """
        Args:
            writer_pool: BigQueryWriterPool instance
            topic_table_mapping: Map topic names to BigQuery table names
        """
        self.writer_pool = writer_pool
        self.topic_table_mapping = topic_table_mapping
    
    async def _execute(self, context: ProcessingContext) -> ProcessingContext:
        # Get table for this topic
        table_name = self.topic_table_mapping.get(context.topic)
        
        if not table_name:
            context.errors.append(f"No table mapping for topic: {context.topic}")
            return context
        
        # Get writer and add record
        writer = self.writer_pool.get_writer(table_name)
        
        # Add Kafka metadata
        record = {
            **context.transformed_data,
            "_kafka_topic": context.raw_message.topic,
            "_kafka_partition": context.raw_message.partition,
            "_kafka_offset": context.raw_message.offset,
        }
        
        writer.add(record)
        
        return context


# =============================================================================
# 6. PIPELINE ORCHESTRATOR
# =============================================================================

class Pipeline:
    """Pipeline orchestrator that chains stages together.
    
    Implements Pipes & Filters pattern.
    """
    
    def __init__(self, stages: list[BaseStage] | None = None):
        self.stages: list[BaseStage] = stages or []
    
    def add_stage(self, stage: BaseStage) -> "Pipeline":
        """Fluent API for adding stages."""
        self.stages.append(stage)
        return self
    
    async def execute(self, message: KafkaMessage) -> ProcessingResult:
        """Execute pipeline on a message."""
        import time
        start_time = time.time()
        
        # Create processing context
        context = ProcessingContext(raw_message=message)
        stages_executed = []
        
        # Execute each stage
        for stage in self.stages:
            context = await stage.process(context)
            stages_executed.append(stage.name)
            
            # Stop pipeline if failed
            if context.status == ProcessingStatus.FAILED:
                break
        
        duration_ms = (time.time() - start_time) * 1000
        
        return ProcessingResult(
            context=context,
            success=context.status in [
                ProcessingStatus.SUCCESS, 
                ProcessingStatus.ENRICHMENT_FAILED
            ],
            duration_ms=duration_ms,
            stages_executed=stages_executed,
        )


# =============================================================================
# 7. PIPELINE BUILDER (Builder Pattern)
# =============================================================================

class PipelineBuilder:
    """Builder for constructing pipelines.
    
    Fluent API for building pipelines with different configurations.
    """
    
    def __init__(self):
        self.stages: list[BaseStage] = []
        self._api_client = None
        self._writer_pool = None
        self._topic_table_mapping = {}
    
    def with_api_client(self, client: Any) -> "PipelineBuilder":
        """Set API client for enrichment."""
        self._api_client = client
        return self
    
    def with_writer_pool(self, pool: Any) -> "PipelineBuilder":
        """Set BigQuery writer pool."""
        self._writer_pool = pool
        return self
    
    def with_topic_mapping(self, mapping: dict[str, str]) -> "PipelineBuilder":
        """Set topic to table mapping."""
        self._topic_table_mapping = mapping
        return self
    
    def with_validation(self, required_fields: list[str] | None = None) -> "PipelineBuilder":
        """Add validation stage."""
        self.stages.append(ValidationStage(required_fields))
        return self
    
    def with_enrichment(self) -> "PipelineBuilder":
        """Add enrichment stage."""
        if not self._api_client:
            raise ValueError("API client required for enrichment. Call with_api_client() first.")
        self.stages.append(EnrichmentStage(self._api_client))
        return self
    
    def with_transformation(
        self, 
        strategies: dict[str, TransformStrategy] | None = None
    ) -> "PipelineBuilder":
        """Add transformation stage."""
        self.stages.append(TransformationStage(strategies))
        return self
    
    def with_bigquery_write(self) -> "PipelineBuilder":
        """Add BigQuery write stage."""
        if not self._writer_pool:
            raise ValueError("Writer pool required. Call with_writer_pool() first.")
        self.stages.append(
            BigQueryWriteStage(self._writer_pool, self._topic_table_mapping)
        )
        return self
    
    def build(self) -> Pipeline:
        """Build the pipeline."""
        return Pipeline(self.stages)


# =============================================================================
# 8. USAGE EXAMPLE
# =============================================================================

async def create_the1_pipeline(
    api_client: Any,
    writer_pool: Any,
) -> Pipeline:
    """Create The1 data pipeline with all stages.
    
    Usage:
        pipeline = await create_the1_pipeline(api_client, writer_pool)
        result = await pipeline.execute(kafka_message)
    """
    
    topic_table_mapping = {
        "loyalty.members.upgraded": "kafka_members_upgraded",
        "loyalty.members.downgraded": "kafka_members_downgraded",
    }
    
    pipeline = (
        PipelineBuilder()
        .with_api_client(api_client)
        .with_writer_pool(writer_pool)
        .with_topic_mapping(topic_table_mapping)
        .with_validation(required_fields=["member_id"])
        .with_enrichment()
        .with_transformation()
        .with_bigquery_write()
        .build()
    )
    
    return pipeline


# Alternative: Simple pipeline without builder
def create_simple_pipeline(
    api_client: Any,
    writer_pool: Any,
) -> Pipeline:
    """Create simple pipeline without builder pattern."""
    
    topic_table_mapping = {
        "loyalty.members.upgraded": "kafka_members_upgraded",
        "loyalty.members.downgraded": "kafka_members_downgraded",
    }
    
    return Pipeline([
        ValidationStage(required_fields=["member_id"]),
        EnrichmentStage(api_client),
        TransformationStage(),
        BigQueryWriteStage(writer_pool, topic_table_mapping),
    ])
