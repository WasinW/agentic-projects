"""Structured logging configuration."""

import logging
import sys
from typing import Any

import structlog
from google.cloud import logging as cloud_logging

from .config import get_settings


def setup_logging(service_name: str = "the1-ingestion") -> None:
    """Configure structured logging for Cloud Run.
    
    Args:
        service_name: Name of the service for log entries
    """
    settings = get_settings()
    
    # Configure structlog
    structlog.configure(
        processors=[
            structlog.stdlib.filter_by_level,
            structlog.stdlib.add_logger_name,
            structlog.stdlib.add_log_level,
            structlog.stdlib.PositionalArgumentsFormatter(),
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.UnicodeDecoder(),
            structlog.processors.JSONRenderer(),
        ],
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )
    
    # Configure Python logging
    logging.basicConfig(
        format="%(message)s",
        stream=sys.stdout,
        level=getattr(logging, settings.log_level.upper()),
    )
    
    # Try to set up Cloud Logging (if running in GCP)
    try:
        if settings.gcp_project:
            client = cloud_logging.Client(project=settings.gcp_project)
            client.setup_logging(log_level=getattr(logging, settings.log_level.upper()))
    except Exception:
        # Running locally, use standard logging
        pass


def get_logger(name: str | None = None) -> structlog.BoundLogger:
    """Get a structured logger.
    
    Args:
        name: Optional logger name
        
    Returns:
        Configured structlog logger
    """
    return structlog.get_logger(name)


class LogContext:
    """Context manager for adding log context."""

    def __init__(self, **kwargs: Any):
        """Initialize with context variables.
        
        Args:
            **kwargs: Context variables to add to logs
        """
        self.context = kwargs
        self._token = None

    def __enter__(self):
        """Enter context and bind variables."""
        structlog.contextvars.clear_contextvars()
        structlog.contextvars.bind_contextvars(**self.context)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit context and clear variables."""
        structlog.contextvars.clear_contextvars()
        return False


def log_execution_time(logger: structlog.BoundLogger, operation: str):
    """Decorator to log execution time of a function.
    
    Args:
        logger: Logger instance
        operation: Name of the operation
    """
    import functools
    import time

    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            try:
                result = func(*args, **kwargs)
                duration_ms = (time.time() - start_time) * 1000
                logger.info(
                    f"{operation}_completed",
                    duration_ms=round(duration_ms, 2),
                )
                return result
            except Exception as e:
                duration_ms = (time.time() - start_time) * 1000
                logger.error(
                    f"{operation}_failed",
                    duration_ms=round(duration_ms, 2),
                    error=str(e),
                )
                raise

        return wrapper

    return decorator


def log_execution_time_async(logger: structlog.BoundLogger, operation: str):
    """Async decorator to log execution time of a function.
    
    Args:
        logger: Logger instance
        operation: Name of the operation
    """
    import functools
    import time

    def decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            start_time = time.time()
            try:
                result = await func(*args, **kwargs)
                duration_ms = (time.time() - start_time) * 1000
                logger.info(
                    f"{operation}_completed",
                    duration_ms=round(duration_ms, 2),
                )
                return result
            except Exception as e:
                duration_ms = (time.time() - start_time) * 1000
                logger.error(
                    f"{operation}_failed",
                    duration_ms=round(duration_ms, 2),
                    error=str(e),
                )
                raise

        return wrapper

    return decorator
