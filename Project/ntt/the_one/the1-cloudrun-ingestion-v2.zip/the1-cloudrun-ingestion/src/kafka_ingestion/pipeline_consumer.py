"""
Kafka Consumer using Pipeline Pattern

This module integrates the Kafka consumer with the Pipeline pattern
for clean, maintainable message processing.
"""

import asyncio
import json
from datetime import datetime, timezone
from typing import Any

from confluent_kafka import Consumer, KafkaError, KafkaException, Message
import structlog

from common import get_settings, get_kafka_credentials
from common.pipeline import (
    Pipeline,
    PipelineBuilder,
    KafkaMessage,
    ProcessingResult,
    ProcessingStatus,
)

logger = structlog.get_logger(__name__)


class PipelineKafkaConsumer:
    """Kafka consumer that processes messages through a pipeline.
    
    Design Patterns Used:
    - Pipeline: For sequential message processing
    - Strategy: For topic-specific transformations
    - Template Method: In pipeline stages
    """

    def __init__(
        self,
        topics: list[str],
        pipeline: Pipeline,
        group_id: str | None = None,
        batch_size: int = 100,
        poll_timeout_seconds: float = 1.0,
    ):
        """Initialize consumer.
        
        Args:
            topics: Kafka topics to subscribe
            pipeline: Pipeline instance for message processing
            group_id: Consumer group ID
            batch_size: Messages before commit
            poll_timeout_seconds: Poll timeout
        """
        self.topics = topics
        self.pipeline = pipeline
        self.batch_size = batch_size
        self.poll_timeout = poll_timeout_seconds
        
        self.settings = get_settings()
        self.group_id = group_id or self.settings.kafka_group_id
        
        self._consumer: Consumer | None = None
        self._running = False
        
        # Stats
        self._stats = {
            "messages_consumed": 0,
            "messages_success": 0,
            "messages_failed": 0,
            "messages_skipped": 0,
            "total_processing_ms": 0,
            "last_commit_time": None,
        }

    def _create_consumer(self) -> Consumer:
        """Create Kafka consumer with Confluent Cloud config."""
        credentials = get_kafka_credentials()
        
        config = {
            "bootstrap.servers": credentials["bootstrap_servers"],
            "security.protocol": "SASL_SSL",
            "sasl.mechanisms": "PLAIN",
            "sasl.username": credentials["api_key"],
            "sasl.password": credentials["api_secret"],
            "group.id": self.group_id,
            "auto.offset.reset": self.settings.kafka_auto_offset_reset,
            "enable.auto.commit": False,
        }
        
        return Consumer(config)

    async def start(self):
        """Start consuming and processing messages."""
        logger.info(
            "pipeline_consumer_starting",
            topics=self.topics,
            group_id=self.group_id,
            pipeline_stages=[s.name for s in self.pipeline.stages],
        )
        
        self._consumer = self._create_consumer()
        self._consumer.subscribe(self.topics)
        self._running = True
        
        messages_since_commit = 0
        
        try:
            while self._running:
                msg = self._consumer.poll(self.poll_timeout)
                
                if msg is None:
                    if messages_since_commit > 0:
                        self._commit()
                        messages_since_commit = 0
                    continue
                
                if msg.error():
                    if msg.error().code() != KafkaError._PARTITION_EOF:
                        logger.error("kafka_error", error=msg.error().str())
                    continue
                
                # Process through pipeline
                result = await self._process_message(msg)
                messages_since_commit += 1
                
                # Update stats
                self._update_stats(result)
                
                # Commit after batch
                if messages_since_commit >= self.batch_size:
                    self._commit()
                    messages_since_commit = 0
                
                await asyncio.sleep(0)  # Yield to event loop
                
        finally:
            if messages_since_commit > 0:
                self._commit()
            if self._consumer:
                self._consumer.close()
            logger.info("pipeline_consumer_stopped")

    async def _process_message(self, msg: Message) -> ProcessingResult:
        """Process single message through pipeline."""
        # Parse message
        try:
            value = json.loads(msg.value().decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError) as e:
            logger.warning("message_parse_error", error=str(e))
            # Return failed result
            return ProcessingResult(
                context=None,
                success=False,
                duration_ms=0,
                stages_executed=[],
            )
        
        # Create KafkaMessage wrapper
        kafka_message = KafkaMessage(
            topic=msg.topic(),
            partition=msg.partition(),
            offset=msg.offset(),
            key=msg.key().decode("utf-8") if msg.key() else None,
            value=value,
            timestamp=msg.timestamp()[1] if msg.timestamp()[0] else None,
        )
        
        # Execute pipeline
        result = await self.pipeline.execute(kafka_message)
        
        # Log result
        if result.success:
            logger.info(
                "message_processed",
                topic=kafka_message.topic,
                offset=kafka_message.offset,
                duration_ms=round(result.duration_ms, 2),
                stages=result.stages_executed,
            )
        else:
            logger.warning(
                "message_processing_failed",
                topic=kafka_message.topic,
                offset=kafka_message.offset,
                errors=result.context.errors if result.context else [],
            )
        
        return result

    def _update_stats(self, result: ProcessingResult):
        """Update processing statistics."""
        self._stats["messages_consumed"] += 1
        self._stats["total_processing_ms"] += result.duration_ms
        
        if result.success:
            self._stats["messages_success"] += 1
        elif result.context and result.context.status == ProcessingStatus.SKIPPED:
            self._stats["messages_skipped"] += 1
        else:
            self._stats["messages_failed"] += 1

    def _commit(self):
        """Commit Kafka offsets."""
        if self._consumer:
            try:
                self._consumer.commit(asynchronous=False)
                self._stats["last_commit_time"] = datetime.now(timezone.utc).isoformat()
            except KafkaException as e:
                logger.error("commit_error", error=str(e))

    async def stop(self):
        """Stop consumer gracefully."""
        logger.info("pipeline_consumer_stopping")
        self._running = False

    def get_stats(self) -> dict[str, Any]:
        """Get consumer statistics."""
        avg_processing_ms = 0
        if self._stats["messages_consumed"] > 0:
            avg_processing_ms = (
                self._stats["total_processing_ms"] / 
                self._stats["messages_consumed"]
            )
        
        return {
            **self._stats,
            "avg_processing_ms": round(avg_processing_ms, 2),
            "success_rate": (
                self._stats["messages_success"] / 
                max(self._stats["messages_consumed"], 1)
            ),
            "running": self._running,
        }


# =============================================================================
# FACTORY FUNCTION - Creates consumer with pipeline
# =============================================================================

async def create_pipeline_consumer(
    api_client: Any,
    writer_pool: Any,
    topics: list[str] | None = None,
) -> PipelineKafkaConsumer:
    """Factory function to create fully configured consumer.
    
    Usage:
        consumer = await create_pipeline_consumer(api_client, writer_pool)
        await consumer.start()
    """
    
    topics = topics or [
        "loyalty.members.upgraded",
        "loyalty.members.downgraded",
    ]
    
    topic_table_mapping = {
        "loyalty.members.upgraded": "kafka_members_upgraded",
        "loyalty.members.downgraded": "kafka_members_downgraded",
    }
    
    # Build pipeline using builder pattern
    pipeline = (
        PipelineBuilder()
        .with_api_client(api_client)
        .with_writer_pool(writer_pool)
        .with_topic_mapping(topic_table_mapping)
        .with_validation(required_fields=["member_id"])
        .with_enrichment()
        .with_transformation()
        .with_bigquery_write()
        .build()
    )
    
    return PipelineKafkaConsumer(
        topics=topics,
        pipeline=pipeline,
    )
