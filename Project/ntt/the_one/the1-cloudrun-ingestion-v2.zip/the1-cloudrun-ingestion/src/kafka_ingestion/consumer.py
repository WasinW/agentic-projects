"""Kafka consumer wrapper for Confluent Cloud."""

import asyncio
import json
from datetime import datetime, timezone
from typing import Any, Callable, Awaitable

from confluent_kafka import Consumer, KafkaError, KafkaException, Message
import structlog

from common import get_settings, get_kafka_credentials

logger = structlog.get_logger(__name__)


class KafkaConsumerWrapper:
    """Wrapper for Confluent Kafka consumer with async support.
    
    Features:
    - SASL/SSL authentication for Confluent Cloud
    - Graceful shutdown with offset commit
    - Error handling and dead letter support
    - Statistics tracking
    """

    def __init__(
        self,
        topics: list[str],
        group_id: str,
        message_handler: Callable[[str, dict[str, Any]], Awaitable[bool]],
        batch_size: int = 100,
        poll_timeout_seconds: float = 1.0,
    ):
        """Initialize Kafka consumer.
        
        Args:
            topics: List of topics to subscribe to
            group_id: Consumer group ID
            message_handler: Async function to handle messages
            batch_size: Number of messages to process before committing
            poll_timeout_seconds: Poll timeout
        """
        self.topics = topics
        self.group_id = group_id
        self.message_handler = message_handler
        self.batch_size = batch_size
        self.poll_timeout = poll_timeout_seconds
        
        self.settings = get_settings()
        self._consumer: Consumer | None = None
        self._running = False
        
        # Stats
        self._messages_consumed = 0
        self._messages_processed = 0
        self._messages_failed = 0
        self._last_commit_time: datetime | None = None

    def _create_consumer(self) -> Consumer:
        """Create and configure Kafka consumer."""
        credentials = get_kafka_credentials()
        
        config = {
            # Connection
            "bootstrap.servers": credentials["bootstrap_servers"],
            "security.protocol": "SASL_SSL",
            "sasl.mechanisms": "PLAIN",
            "sasl.username": credentials["api_key"],
            "sasl.password": credentials["api_secret"],
            
            # Consumer group
            "group.id": self.group_id,
            "auto.offset.reset": self.settings.kafka_auto_offset_reset,
            
            # Commit behavior
            "enable.auto.commit": False,  # Manual commit for exactly-once
            
            # Performance
            "fetch.min.bytes": 1,
            "fetch.wait.max.ms": 500,
            "max.poll.interval.ms": 300000,  # 5 minutes
            
            # Error handling
            "error_cb": self._error_callback,
        }
        
        return Consumer(config)

    def _error_callback(self, error: KafkaError):
        """Handle Kafka errors."""
        logger.error(
            "kafka_error",
            error_code=error.code(),
            error_name=error.name(),
            error_str=str(error),
        )

    async def start(self):
        """Start consuming messages."""
        logger.info(
            "consumer_starting",
            topics=self.topics,
            group_id=self.group_id,
        )
        
        self._consumer = self._create_consumer()
        self._consumer.subscribe(self.topics)
        self._running = True
        
        messages_since_commit = 0
        
        try:
            while self._running:
                # Poll for messages
                msg = self._consumer.poll(self.poll_timeout)
                
                if msg is None:
                    # No message, check if we should commit
                    if messages_since_commit > 0:
                        self._commit()
                        messages_since_commit = 0
                    continue
                
                if msg.error():
                    if msg.error().code() == KafkaError._PARTITION_EOF:
                        # End of partition, not an error
                        continue
                    else:
                        logger.error(
                            "message_error",
                            error=msg.error().str(),
                        )
                        continue
                
                # Process message
                self._messages_consumed += 1
                
                try:
                    success = await self._process_message(msg)
                    
                    if success:
                        self._messages_processed += 1
                    else:
                        self._messages_failed += 1
                    
                    messages_since_commit += 1
                    
                    # Commit after batch_size messages
                    if messages_since_commit >= self.batch_size:
                        self._commit()
                        messages_since_commit = 0
                        
                except Exception as e:
                    self._messages_failed += 1
                    logger.error(
                        "message_processing_error",
                        topic=msg.topic(),
                        partition=msg.partition(),
                        offset=msg.offset(),
                        error=str(e),
                    )
                
                # Yield control to event loop
                await asyncio.sleep(0)
                
        except Exception as e:
            logger.error("consumer_error", error=str(e))
            raise
            
        finally:
            # Final commit before shutdown
            if messages_since_commit > 0:
                self._commit()
            
            if self._consumer:
                self._consumer.close()
                
            logger.info("consumer_stopped")

    async def _process_message(self, msg: Message) -> bool:
        """Process a single message.
        
        Args:
            msg: Kafka message
            
        Returns:
            True if processed successfully
        """
        topic = msg.topic()
        
        # Deserialize message
        try:
            value = json.loads(msg.value().decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError) as e:
            logger.warning(
                "message_deserialize_error",
                topic=topic,
                error=str(e),
            )
            return False
        
        # Add Kafka metadata
        value["_kafka_topic"] = topic
        value["_kafka_partition"] = msg.partition()
        value["_kafka_offset"] = msg.offset()
        value["_kafka_timestamp"] = msg.timestamp()[1] if msg.timestamp()[0] else None
        
        # Call handler
        return await self.message_handler(topic, value)

    def _commit(self):
        """Commit current offsets."""
        if self._consumer:
            try:
                self._consumer.commit(asynchronous=False)
                self._last_commit_time = datetime.now(timezone.utc)
                
                logger.debug(
                    "offsets_committed",
                    messages_processed=self._messages_processed,
                )
            except KafkaException as e:
                logger.error("commit_error", error=str(e))

    async def stop(self):
        """Stop the consumer gracefully."""
        logger.info("consumer_stopping")
        self._running = False

    def get_stats(self) -> dict[str, Any]:
        """Get consumer statistics.
        
        Returns:
            Dictionary with stats
        """
        return {
            "topics": self.topics,
            "group_id": self.group_id,
            "running": self._running,
            "messages_consumed": self._messages_consumed,
            "messages_processed": self._messages_processed,
            "messages_failed": self._messages_failed,
            "last_commit_time": (
                self._last_commit_time.isoformat() 
                if self._last_commit_time else None
            ),
        }
