"""Kafka message handlers - business logic for each topic."""

from datetime import datetime, timezone
from typing import Any

import structlog

from common import BigQueryWriterPool, RecordTransformer

logger = structlog.get_logger(__name__)


# Topic to table mapping
TOPIC_TABLE_MAPPING = {
    "loyalty.members.upgraded": "kafka_members_upgraded",
    "loyalty.members.downgraded": "kafka_members_downgraded",
}


class MessageHandler:
    """Handler for Kafka messages.
    
    Routes messages to appropriate BigQuery tables
    based on topic and applies transformations.
    """

    def __init__(self, writer_pool: BigQueryWriterPool):
        """Initialize handler.
        
        Args:
            writer_pool: BigQuery writer pool
        """
        self.writer_pool = writer_pool
        
        # Create transformers for each topic
        self.transformers: dict[str, RecordTransformer] = {}
        for topic in TOPIC_TABLE_MAPPING:
            self.transformers[topic] = RecordTransformer(
                flatten=True,
                snake_case_keys=True,
                source=f"kafka_{topic}",
            )
        
        # Stats
        self._messages_handled = 0
        self._messages_by_topic: dict[str, int] = {}

    async def handle_message(self, topic: str, message: dict[str, Any]) -> bool:
        """Handle a single Kafka message.
        
        Args:
            topic: Kafka topic name
            message: Deserialized message data
            
        Returns:
            True if handled successfully
        """
        # Get table name for topic
        table_name = TOPIC_TABLE_MAPPING.get(topic)
        
        if not table_name:
            logger.warning("unknown_topic", topic=topic)
            return False
        
        # Get transformer
        transformer = self.transformers.get(topic)
        
        if not transformer:
            logger.error("no_transformer_for_topic", topic=topic)
            return False
        
        try:
            # Extract source timestamp from message if available
            source_timestamp = None
            if "_kafka_timestamp" in message and message["_kafka_timestamp"]:
                source_timestamp = datetime.fromtimestamp(
                    message["_kafka_timestamp"] / 1000,  # Kafka uses milliseconds
                    tz=timezone.utc
                )
            
            # Transform message
            transformed = transformer.transform(message, source_timestamp)
            
            # Write to BigQuery
            writer = self.writer_pool.get_writer(table_name)
            writer.add(transformed)
            
            # Update stats
            self._messages_handled += 1
            self._messages_by_topic[topic] = self._messages_by_topic.get(topic, 0) + 1
            
            logger.debug(
                "message_handled",
                topic=topic,
                table=table_name,
            )
            
            return True
            
        except Exception as e:
            logger.error(
                "message_handling_error",
                topic=topic,
                error=str(e),
            )
            return False

    async def handle_upgrade_event(self, message: dict[str, Any]) -> bool:
        """Handle member upgrade event.
        
        Args:
            message: Upgrade event data
            
        Returns:
            True if handled successfully
        """
        return await self.handle_message("loyalty.members.upgraded", message)

    async def handle_downgrade_event(self, message: dict[str, Any]) -> bool:
        """Handle member downgrade event.
        
        Args:
            message: Downgrade event data
            
        Returns:
            True if handled successfully
        """
        return await self.handle_message("loyalty.members.downgraded", message)

    def get_stats(self) -> dict[str, Any]:
        """Get handler statistics.
        
        Returns:
            Dictionary with stats
        """
        return {
            "messages_handled": self._messages_handled,
            "messages_by_topic": self._messages_by_topic,
        }
