"""Kafka Ingestion Service - Long-running consumer.

This service consumes messages from Confluent Cloud Kafka
and writes them to BigQuery using Storage Write API.
"""

import asyncio
import signal
import sys
from datetime import datetime, timezone
from typing import Any

import structlog

from common import (
    setup_logging,
    get_logger,
    get_settings,
    BigQueryWriterPool,
)
from .consumer import KafkaConsumerWrapper
from .handlers import MessageHandler

# Setup logging
setup_logging("the1-kafka-ingestion")
logger = get_logger(__name__)


class KafkaIngestionService:
    """Kafka ingestion service orchestrator."""

    def __init__(self):
        """Initialize service."""
        self.settings = get_settings()
        self.running = False
        
        # Components
        self.writer_pool: BigQueryWriterPool | None = None
        self.consumer: KafkaConsumerWrapper | None = None
        self.handler: MessageHandler | None = None

    async def start(self):
        """Start the service."""
        logger.info("service_starting")
        
        # Initialize BigQuery writer pool
        self.writer_pool = BigQueryWriterPool(
            project_id=self.settings.gcp_project,
            dataset_id=self.settings.bq_dataset,
        )
        
        # Initialize message handler
        self.handler = MessageHandler(self.writer_pool)
        
        # Initialize Kafka consumer
        topics = [
            "loyalty.members.upgraded",
            "loyalty.members.downgraded",
        ]
        
        self.consumer = KafkaConsumerWrapper(
            topics=topics,
            group_id=self.settings.kafka_group_id,
            message_handler=self.handler.handle_message,
        )
        
        self.running = True
        logger.info("service_started", topics=topics)
        
        # Start consuming
        await self.consumer.start()

    async def stop(self):
        """Stop the service gracefully."""
        logger.info("service_stopping")
        
        self.running = False
        
        # Stop consumer
        if self.consumer:
            await self.consumer.stop()
        
        # Flush and close writers
        if self.writer_pool:
            self.writer_pool.close_all()
        
        logger.info("service_stopped")

    def get_stats(self) -> dict[str, Any]:
        """Get service statistics.
        
        Returns:
            Dictionary with stats
        """
        stats = {
            "running": self.running,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        
        if self.consumer:
            stats["consumer"] = self.consumer.get_stats()
        
        if self.handler:
            stats["handler"] = self.handler.get_stats()
        
        if self.writer_pool:
            stats["writers"] = self.writer_pool.get_all_stats()
        
        return stats


async def main():
    """Main entry point."""
    service = KafkaIngestionService()
    
    # Setup signal handlers for graceful shutdown
    loop = asyncio.get_event_loop()
    
    def signal_handler():
        logger.info("shutdown_signal_received")
        asyncio.create_task(service.stop())
    
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, signal_handler)
    
    try:
        await service.start()
        
        # Keep running until stopped
        while service.running:
            await asyncio.sleep(1)
            
    except KeyboardInterrupt:
        logger.info("keyboard_interrupt")
    except Exception as e:
        logger.error("service_error", error=str(e))
        raise
    finally:
        await service.stop()


if __name__ == "__main__":
    asyncio.run(main())
