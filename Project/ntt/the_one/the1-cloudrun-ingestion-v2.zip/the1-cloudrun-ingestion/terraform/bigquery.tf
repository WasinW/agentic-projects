# BigQuery dataset and tables configuration

# Dataset
resource "google_bigquery_dataset" "loyalty_raw" {
  dataset_id  = var.bq_dataset_id
  location    = var.bq_location
  description = "Raw ingestion data from The1 Loyalty API and Kafka"
  
  labels = local.common_labels
  
  # Default table expiration (optional)
  # default_table_expiration_ms = 2592000000  # 30 days
  
  depends_on = [google_project_service.required_apis]
}

# API Tables
resource "google_bigquery_table" "api_tiers" {
  dataset_id = google_bigquery_dataset.loyalty_raw.dataset_id
  table_id   = "api_tiers"
  
  description = "Tier definitions from Loyalty API"
  
  time_partitioning {
    type  = "DAY"
    field = "_ingested_at"
  }
  
  schema = jsonencode([
    { name = "tier_id", type = "STRING", mode = "REQUIRED" },
    { name = "tier_name", type = "STRING" },
    { name = "tier_level", type = "INTEGER" },
    { name = "min_points", type = "INTEGER" },
    { name = "max_points", type = "INTEGER" },
    { name = "benefits", type = "JSON" },
    { name = "_source", type = "STRING" },
    { name = "_ingested_at", type = "TIMESTAMP", mode = "REQUIRED" },
    { name = "_source_timestamp", type = "TIMESTAMP" },
  ])
  
  labels = local.common_labels
}

resource "google_bigquery_table" "api_members" {
  dataset_id = google_bigquery_dataset.loyalty_raw.dataset_id
  table_id   = "api_members"
  
  description = "Member information from Loyalty API"
  
  time_partitioning {
    type  = "DAY"
    field = "_ingested_at"
  }
  
  clustering = ["member_id", "tier_id"]
  
  schema = jsonencode([
    { name = "member_id", type = "STRING", mode = "REQUIRED" },
    { name = "first_name", type = "STRING" },
    { name = "last_name", type = "STRING" },
    { name = "email", type = "STRING" },
    { name = "phone", type = "STRING" },
    { name = "tier_id", type = "STRING" },
    { name = "total_points", type = "INTEGER" },
    { name = "member_since", type = "TIMESTAMP" },
    { name = "status", type = "STRING" },
    { name = "_source", type = "STRING" },
    { name = "_ingested_at", type = "TIMESTAMP", mode = "REQUIRED" },
    { name = "_source_timestamp", type = "TIMESTAMP" },
  ])
  
  labels = local.common_labels
}

resource "google_bigquery_table" "api_accounts" {
  dataset_id = google_bigquery_dataset.loyalty_raw.dataset_id
  table_id   = "api_accounts"
  
  description = "Member accounts from Loyalty API"
  
  time_partitioning {
    type  = "DAY"
    field = "_ingested_at"
  }
  
  clustering = ["member_id"]
  
  schema = jsonencode([
    { name = "account_id", type = "STRING", mode = "REQUIRED" },
    { name = "member_id", type = "STRING", mode = "REQUIRED" },
    { name = "account_type", type = "STRING" },
    { name = "balance", type = "FLOAT" },
    { name = "currency", type = "STRING" },
    { name = "status", type = "STRING" },
    { name = "created_at", type = "TIMESTAMP" },
    { name = "_source", type = "STRING" },
    { name = "_ingested_at", type = "TIMESTAMP", mode = "REQUIRED" },
    { name = "_source_timestamp", type = "TIMESTAMP" },
  ])
  
  labels = local.common_labels
}

resource "google_bigquery_table" "api_tier_events" {
  dataset_id = google_bigquery_dataset.loyalty_raw.dataset_id
  table_id   = "api_tier_events"
  
  description = "Member tier event history from Loyalty API"
  
  time_partitioning {
    type  = "DAY"
    field = "_ingested_at"
  }
  
  clustering = ["member_id", "event_type"]
  
  schema = jsonencode([
    { name = "event_id", type = "STRING", mode = "REQUIRED" },
    { name = "member_id", type = "STRING", mode = "REQUIRED" },
    { name = "event_type", type = "STRING" },
    { name = "from_tier_id", type = "STRING" },
    { name = "to_tier_id", type = "STRING" },
    { name = "event_date", type = "TIMESTAMP" },
    { name = "reason", type = "STRING" },
    { name = "points_at_event", type = "INTEGER" },
    { name = "_source", type = "STRING" },
    { name = "_ingested_at", type = "TIMESTAMP", mode = "REQUIRED" },
    { name = "_source_timestamp", type = "TIMESTAMP" },
  ])
  
  labels = local.common_labels
}

# Kafka Tables
resource "google_bigquery_table" "kafka_members_upgraded" {
  dataset_id = google_bigquery_dataset.loyalty_raw.dataset_id
  table_id   = "kafka_members_upgraded"
  
  description = "Member tier upgrade events from Kafka"
  
  time_partitioning {
    type  = "DAY"
    field = "_ingested_at"
  }
  
  clustering = ["member_id"]
  
  schema = jsonencode([
    { name = "member_id", type = "STRING", mode = "REQUIRED" },
    { name = "previous_tier_id", type = "STRING" },
    { name = "new_tier_id", type = "STRING" },
    { name = "upgraded_at", type = "TIMESTAMP" },
    { name = "reason", type = "STRING" },
    { name = "points_at_upgrade", type = "INTEGER" },
    { name = "_kafka_topic", type = "STRING" },
    { name = "_kafka_partition", type = "INTEGER" },
    { name = "_kafka_offset", type = "INTEGER" },
    { name = "_kafka_timestamp", type = "INTEGER" },
    { name = "_source", type = "STRING" },
    { name = "_ingested_at", type = "TIMESTAMP", mode = "REQUIRED" },
    { name = "_source_timestamp", type = "TIMESTAMP" },
  ])
  
  labels = local.common_labels
}

resource "google_bigquery_table" "kafka_members_downgraded" {
  dataset_id = google_bigquery_dataset.loyalty_raw.dataset_id
  table_id   = "kafka_members_downgraded"
  
  description = "Member tier downgrade events from Kafka"
  
  time_partitioning {
    type  = "DAY"
    field = "_ingested_at"
  }
  
  clustering = ["member_id"]
  
  schema = jsonencode([
    { name = "member_id", type = "STRING", mode = "REQUIRED" },
    { name = "previous_tier_id", type = "STRING" },
    { name = "new_tier_id", type = "STRING" },
    { name = "downgraded_at", type = "TIMESTAMP" },
    { name = "reason", type = "STRING" },
    { name = "points_at_downgrade", type = "INTEGER" },
    { name = "_kafka_topic", type = "STRING" },
    { name = "_kafka_partition", type = "INTEGER" },
    { name = "_kafka_offset", type = "INTEGER" },
    { name = "_kafka_timestamp", type = "INTEGER" },
    { name = "_source", type = "STRING" },
    { name = "_ingested_at", type = "TIMESTAMP", mode = "REQUIRED" },
    { name = "_source_timestamp", type = "TIMESTAMP" },
  ])
  
  labels = local.common_labels
}

# Dead Letter Table
resource "google_bigquery_table" "kafka_dead_letter" {
  dataset_id = google_bigquery_dataset.loyalty_raw.dataset_id
  table_id   = "kafka_dead_letter"
  
  description = "Failed messages from Kafka ingestion"
  
  time_partitioning {
    type                     = "DAY"
    field                    = "failed_at"
    expiration_ms            = 2592000000  # 30 days
  }
  
  schema = jsonencode([
    { name = "message_id", type = "STRING", mode = "REQUIRED" },
    { name = "topic", type = "STRING" },
    { name = "partition", type = "INTEGER" },
    { name = "offset", type = "INTEGER" },
    { name = "key", type = "STRING" },
    { name = "value", type = "JSON" },
    { name = "error_message", type = "STRING" },
    { name = "error_type", type = "STRING" },
    { name = "failed_at", type = "TIMESTAMP", mode = "REQUIRED" },
    { name = "retry_count", type = "INTEGER" },
  ])
  
  labels = local.common_labels
}

# Outputs
output "dataset_id" {
  description = "BigQuery dataset ID"
  value       = google_bigquery_dataset.loyalty_raw.dataset_id
}

output "table_ids" {
  description = "BigQuery table IDs"
  value = {
    api_tiers              = google_bigquery_table.api_tiers.table_id
    api_members            = google_bigquery_table.api_members.table_id
    api_accounts           = google_bigquery_table.api_accounts.table_id
    api_tier_events        = google_bigquery_table.api_tier_events.table_id
    kafka_members_upgraded = google_bigquery_table.kafka_members_upgraded.table_id
    kafka_members_downgraded = google_bigquery_table.kafka_members_downgraded.table_id
    kafka_dead_letter      = google_bigquery_table.kafka_dead_letter.table_id
  }
}
