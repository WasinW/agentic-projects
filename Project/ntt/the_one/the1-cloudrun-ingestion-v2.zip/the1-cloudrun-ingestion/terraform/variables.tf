# Terraform variables for The1 Cloud Run Ingestion

variable "project_id" {
  description = "GCP Project ID"
  type        = string
}

variable "region" {
  description = "GCP Region"
  type        = string
  default     = "asia-southeast1"
}

variable "environment" {
  description = "Environment name (dev, staging, prod)"
  type        = string
  default     = "prod"
}

# BigQuery variables
variable "bq_dataset_id" {
  description = "BigQuery dataset ID"
  type        = string
  default     = "the1_loyalty_raw"
}

variable "bq_location" {
  description = "BigQuery dataset location"
  type        = string
  default     = "asia-southeast1"
}

# Cloud Run variables
variable "api_service_cpu" {
  description = "CPU allocation for API service"
  type        = string
  default     = "1"
}

variable "api_service_memory" {
  description = "Memory allocation for API service"
  type        = string
  default     = "512Mi"
}

variable "kafka_service_cpu" {
  description = "CPU allocation for Kafka service"
  type        = string
  default     = "1"
}

variable "kafka_service_memory" {
  description = "Memory allocation for Kafka service"
  type        = string
  default     = "1Gi"
}

variable "min_instances" {
  description = "Minimum number of instances for Kafka service"
  type        = number
  default     = 1
}

variable "max_instances" {
  description = "Maximum number of instances"
  type        = number
  default     = 5
}

# VPC variables
variable "create_vpc_connector" {
  description = "Whether to create VPC connector"
  type        = bool
  default     = false
}

variable "vpc_network" {
  description = "VPC network name for connector"
  type        = string
  default     = "default"
}

variable "vpc_connector_cidr" {
  description = "CIDR range for VPC connector"
  type        = string
  default     = "10.8.0.0/28"
}

# Secret Manager variables
variable "api_secret_name" {
  description = "Secret name for API credentials"
  type        = string
  default     = "prod/api/authenToken"
}

variable "kafka_secret_name" {
  description = "Secret name for Kafka credentials"
  type        = string
  default     = "prod/the1ConfluentKafka"
}

# Scheduler variables
variable "scheduler_timezone" {
  description = "Timezone for Cloud Scheduler"
  type        = string
  default     = "Asia/Bangkok"
}

variable "tiers_sync_schedule" {
  description = "Cron schedule for tiers sync"
  type        = string
  default     = "0 2 * * *"  # Daily at 2 AM
}
