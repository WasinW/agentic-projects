# Cloud Run services configuration

# API Ingestion Service
resource "google_cloud_run_v2_service" "api_ingestion" {
  name     = local.service_name_api
  location = var.region
  
  template {
    service_account = google_service_account.ingestion_sa.email
    
    scaling {
      min_instance_count = 0
      max_instance_count = var.max_instances
    }
    
    containers {
      image = "${var.region}-docker.pkg.dev/${var.project_id}/${google_artifact_registry_repository.ingestion_repo.repository_id}/${local.service_name_api}:latest"
      
      resources {
        limits = {
          cpu    = var.api_service_cpu
          memory = var.api_service_memory
        }
      }
      
      env {
        name  = "GCP_PROJECT"
        value = var.project_id
      }
      
      env {
        name  = "GCP_REGION"
        value = var.region
      }
      
      env {
        name  = "BQ_DATASET"
        value = var.bq_dataset_id
      }
      
      env {
        name  = "API_SECRET_NAME"
        value = var.api_secret_name
      }
      
      env {
        name  = "LOG_LEVEL"
        value = "INFO"
      }
      
      ports {
        container_port = 8080
      }
      
      startup_probe {
        http_get {
          path = "/health"
          port = 8080
        }
        initial_delay_seconds = 5
        timeout_seconds       = 3
        period_seconds        = 10
        failure_threshold     = 3
      }
      
      liveness_probe {
        http_get {
          path = "/health"
          port = 8080
        }
        period_seconds    = 30
        timeout_seconds   = 5
        failure_threshold = 3
      }
    }
    
    # VPC connector for AWS endpoint access
    dynamic "vpc_access" {
      for_each = var.create_vpc_connector ? [1] : []
      content {
        connector = google_vpc_access_connector.connector[0].id
        egress    = "PRIVATE_RANGES_ONLY"
      }
    }
  }
  
  labels = local.common_labels
  
  depends_on = [
    google_project_service.required_apis,
    google_project_iam_member.ingestion_sa_roles,
  ]
}

# Kafka Ingestion Service (always-on)
resource "google_cloud_run_v2_service" "kafka_ingestion" {
  name     = local.service_name_kafka
  location = var.region
  
  template {
    service_account = google_service_account.ingestion_sa.email
    
    # Always-on configuration
    scaling {
      min_instance_count = var.min_instances
      max_instance_count = var.max_instances
    }
    
    # Disable CPU throttling for background processing
    annotations = {
      "run.googleapis.com/cpu-throttling" = "false"
    }
    
    containers {
      image = "${var.region}-docker.pkg.dev/${var.project_id}/${google_artifact_registry_repository.ingestion_repo.repository_id}/${local.service_name_kafka}:latest"
      
      resources {
        limits = {
          cpu    = var.kafka_service_cpu
          memory = var.kafka_service_memory
        }
        cpu_idle = false  # Keep CPU allocated
      }
      
      env {
        name  = "GCP_PROJECT"
        value = var.project_id
      }
      
      env {
        name  = "GCP_REGION"
        value = var.region
      }
      
      env {
        name  = "BQ_DATASET"
        value = var.bq_dataset_id
      }
      
      env {
        name  = "KAFKA_SECRET_NAME"
        value = var.kafka_secret_name
      }
      
      env {
        name  = "KAFKA_GROUP_ID"
        value = "the1-cloudrun-ingestion"
      }
      
      env {
        name  = "LOG_LEVEL"
        value = "INFO"
      }
    }
  }
  
  labels = local.common_labels
  
  depends_on = [
    google_project_service.required_apis,
    google_project_iam_member.ingestion_sa_roles,
  ]
}

# IAM for Cloud Scheduler to invoke API service
resource "google_cloud_run_v2_service_iam_member" "scheduler_invoker" {
  project  = var.project_id
  location = var.region
  name     = google_cloud_run_v2_service.api_ingestion.name
  role     = "roles/run.invoker"
  member   = "serviceAccount:${google_service_account.scheduler_sa.email}"
}

# Service account for Cloud Scheduler
resource "google_service_account" "scheduler_sa" {
  account_id   = "the1-scheduler-sa"
  display_name = "The1 Cloud Scheduler Service Account"
}

# Outputs
output "api_service_url" {
  description = "API Ingestion Service URL"
  value       = google_cloud_run_v2_service.api_ingestion.uri
}

output "kafka_service_name" {
  description = "Kafka Ingestion Service Name"
  value       = google_cloud_run_v2_service.kafka_ingestion.name
}
