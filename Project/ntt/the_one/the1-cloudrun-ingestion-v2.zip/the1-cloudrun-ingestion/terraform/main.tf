# Terraform configuration for The1 Cloud Run Ingestion
# Main configuration file

terraform {
  required_version = ">= 1.5.0"
  
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.0"
    }
    google-beta = {
      source  = "hashicorp/google-beta"
      version = "~> 5.0"
    }
  }
  
  # Backend configuration (uncomment and configure for remote state)
  # backend "gcs" {
  #   bucket = "your-terraform-state-bucket"
  #   prefix = "the1-cloudrun-ingestion"
  # }
}

provider "google" {
  project = var.project_id
  region  = var.region
}

provider "google-beta" {
  project = var.project_id
  region  = var.region
}

# Local variables
locals {
  service_name_api   = "the1-api-ingestion"
  service_name_kafka = "the1-kafka-ingestion"
  
  common_labels = {
    environment = var.environment
    managed_by  = "terraform"
    application = "the1-ingestion"
  }
}

# Enable required APIs
resource "google_project_service" "required_apis" {
  for_each = toset([
    "run.googleapis.com",
    "bigquery.googleapis.com",
    "secretmanager.googleapis.com",
    "cloudscheduler.googleapis.com",
    "artifactregistry.googleapis.com",
    "cloudbuild.googleapis.com",
    "vpcaccess.googleapis.com",
  ])
  
  project = var.project_id
  service = each.value
  
  disable_on_destroy = false
}

# Service account for Cloud Run services
resource "google_service_account" "ingestion_sa" {
  account_id   = "the1-ingestion-sa"
  display_name = "The1 Ingestion Service Account"
  description  = "Service account for The1 Cloud Run ingestion services"
}

# IAM bindings for service account
resource "google_project_iam_member" "ingestion_sa_roles" {
  for_each = toset([
    "roles/bigquery.dataEditor",
    "roles/bigquery.jobUser",
    "roles/secretmanager.secretAccessor",
    "roles/logging.logWriter",
    "roles/monitoring.metricWriter",
  ])
  
  project = var.project_id
  role    = each.value
  member  = "serviceAccount:${google_service_account.ingestion_sa.email}"
}

# Artifact Registry repository for Docker images
resource "google_artifact_registry_repository" "ingestion_repo" {
  location      = var.region
  repository_id = "the1-ingestion"
  description   = "Docker repository for The1 ingestion services"
  format        = "DOCKER"
  
  labels = local.common_labels
  
  depends_on = [google_project_service.required_apis]
}

# VPC Connector (for accessing AWS VPC endpoint)
resource "google_vpc_access_connector" "connector" {
  count = var.create_vpc_connector ? 1 : 0
  
  name          = "the1-ingestion-connector"
  region        = var.region
  ip_cidr_range = var.vpc_connector_cidr
  network       = var.vpc_network
  
  depends_on = [google_project_service.required_apis]
}

# Output values
output "service_account_email" {
  description = "Service account email"
  value       = google_service_account.ingestion_sa.email
}

output "artifact_registry_url" {
  description = "Artifact Registry URL"
  value       = "${var.region}-docker.pkg.dev/${var.project_id}/${google_artifact_registry_repository.ingestion_repo.repository_id}"
}

output "vpc_connector_name" {
  description = "VPC Connector name (if created)"
  value       = var.create_vpc_connector ? google_vpc_access_connector.connector[0].name : null
}
