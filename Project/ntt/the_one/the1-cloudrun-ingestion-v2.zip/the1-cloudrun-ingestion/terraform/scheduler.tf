# Cloud Scheduler configuration for periodic jobs

# Tiers sync job - Daily at 2 AM
resource "google_cloud_scheduler_job" "tiers_sync" {
  name        = "the1-tiers-sync"
  description = "Daily sync of tier definitions"
  schedule    = var.tiers_sync_schedule
  time_zone   = var.scheduler_timezone
  
  http_target {
    http_method = "POST"
    uri         = "${google_cloud_run_v2_service.api_ingestion.uri}/ingest/tiers"
    
    oidc_token {
      service_account_email = google_service_account.scheduler_sa.email
      audience              = google_cloud_run_v2_service.api_ingestion.uri
    }
    
    headers = {
      "Content-Type" = "application/json"
    }
  }
  
  retry_config {
    retry_count          = 3
    max_retry_duration   = "300s"
    min_backoff_duration = "10s"
    max_backoff_duration = "60s"
  }
  
  depends_on = [
    google_project_service.required_apis,
    google_cloud_run_v2_service.api_ingestion,
  ]
}

# Output
output "scheduler_job_name" {
  description = "Cloud Scheduler job name"
  value       = google_cloud_scheduler_job.tiers_sync.name
}
